<?php
    /*
        The VersionCode controls the automatic update. It is checked every login.
        If an update requires a database change, increase the version code and add the changes for this number to ui/postupdate.php
        After an update, the user will see this page if the code of this installation is lower and can apply the changes.
    */
    $versioncode = 2;
?>
