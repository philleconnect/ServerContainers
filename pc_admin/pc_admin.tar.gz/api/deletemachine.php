<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } else {
        include "dbconnect.php";
        $request = "DELETE FROM machines WHERE room = '".mysqli_real_escape_string($database, $_POST['hardwareid'])."'";
        $query = mysqli_query($database, $request);
        if ($query == true) {
            echo 'success';
        } else {
            echo 'error';
        }
    }
?>
