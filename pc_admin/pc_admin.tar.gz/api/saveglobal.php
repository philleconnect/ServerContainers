<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } elseif ($_SESSION['type'] != '1') {
        echo 'denied';
    } else {
        include "dbconnect.php";
        include "accessConfig.php";
        if ($_POST['prefix'] == 'ldap') {
            changeConfigValue('ldap', 'url', $_POST['url']);
            changeConfigValue('ldap', 'password', $_POST['password']);
            changeConfigValue('ldap', 'basedn', $_POST['basedn']);
            changeConfigValue('ldap', 'admindn', $_POST['admindn']);
            changeConfigValue('ldap', 'usersdn', $_POST['usersdn']);
            changeConfigValue('ldap', 'groupsdn', $_POST['groupsdn']);
            changeConfigValue('ldap', 'studentscn', $_POST['studentscn']);
            changeConfigValue('ldap', 'teacherscn', $_POST['teacherscn']);
            changeConfigValue('ldap', 'sambahostname', $_POST['sambahostname']);
        } elseif ($_POST['prefix'] == 'ipfire') {
            changeConfigValue('ipfire', 'url', $_POST['url']);
            changeConfigValue('ipfire', 'user', $_POST['user']);
            changeConfigValue('ipfire', 'pubkey', $_POST['pubkey']);
            changeConfigValue('ipfire', 'rsafile', $_POST['rsafile']);
        } elseif ($_POST['prefix'] == 'globalPw') {
            changeConfigValue('globalPw', null, $_POST['globalPw']);
        }
        echo 'success';
    }
?>
