<?php
    function addLogEntry($action, $user, $machine, $target) {
        $request = "INSERT INTO log (action, user, machine, date, target) VALUES (".$action.", '".mysqli_real_escape_string($database, $user)."', '".mysqli_real_escape_string($database, $machine)."', ".time().", '".mysqli_real_escape_string($database, $target)."')";
        if (mysqli_query($database, $request)) {
            return true;
        } else {
            return false;
        }
    }
?>