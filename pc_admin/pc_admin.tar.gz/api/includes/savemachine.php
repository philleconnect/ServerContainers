<?php
    if ($client_request->savemachine->mode == 'new') {
        $request = "INSERT INTO machines (room, machine, hardwareid, ip) VALUES ('".mysqli_real_escape_string($database, $client_request->savemachine->room)."', '".mysqli_real_escape_string($database, $client_request->savemachine->name)."', '".mysqli_real_escape_string($database, $client_request->savemachine->machine)."', '".mysqli_real_escape_string($database, $client_request->savemachine->ip)."')";
    } else {
        $request = "UPDATE machines SET room = '".mysqli_real_escape_string($database, $client_request->savemachine->room)."', machine = '".mysqli_real_escape_string($database, $client_request->savemachine->machine)."', config_win = '".mysqli_real_escape_string($database, $client_request->savemachine->config_win)."', config_linux = '".mysqli_real_escape_string($database, $client_request->savemachine->config_linux)."', teacher = ".mysqli_real_escape_string($database, $client_request->savemachine->teacherpc).", inet = ".mysqli_real_escape_string($database, $client_request->savemachine->inet)." WHERE id = ".mysqli_real_escape_string($database, $client_request->savemachine->id);
    }
    $query = mysqli_query($database, $request);
    if ($query == true) {
        $client_response['savemachine'] = 'SUCCESS';
    } else {
        $client_response['savemachine'] = 'ERR_UPDATE_FAILED';
    }
?>