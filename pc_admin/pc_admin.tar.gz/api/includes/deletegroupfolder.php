<?php
    include 'updatesamba.php';
    include 'directoryFunctions.php';
    $request = "DELETE FROM groupfolders WHERE id = ".mysqli_real_escape_string($database, $client_request->deletegroupfolder->id);
    if (mysqli_query($database, $request)) {
        if (updateSambaServer() == true) {
            if ($client_request->deletegroupfolder->deletefolder) {
                if (deleteDirectory($client_request->deletegroupfolder->path)) {
                    $client_response['deletegroupfolder'] = 'SUCCESS';
                } else {
                    $client_response['deletegroupfolder'] = 'ERR_DELETE_FOLDER';
                }
            } else {
                $client_response['deletegroupfolder'] = 'SUCCESS';
            }
        } else {
            $client_response['deletegroupfolder'] = 'ERR_UPDATE_SAMBA';
        }
    } else {
        $client_response['deletegroupfolder'] = 'ERR_DATABASE_ERROR';
    }
?>
