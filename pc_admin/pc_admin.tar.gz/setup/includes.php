<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../ui/ressources/css/main.css" type="text/css">
<link rel="stylesheet" href="../ui/ressources/css/table.css" type="text/css">
<link rel="stylesheet" href="../ui/ressources/css/swal.css" type="text/css">
<script src="../ui/ressources/js/responsive-nav.min.js"></script>
<script src="../ui/ressources/js/jquery.min.js"></script>
<script src="../ui/ressources/js/swal.min.js"></script>
<meta name="robots" content="noindex">