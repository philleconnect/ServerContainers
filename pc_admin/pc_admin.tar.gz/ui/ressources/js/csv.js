/*
 CSV JavaScript Engine for PhilleConnect Admin Backend
 Written by Johannes Kreutz
 */
function getAjaxRequest() {
    var ajax = null;
    ajax = new XMLHttpRequest;
    return ajax;
}
var csv = {
    //Array with the CSV text, one line for each object
    inputArray: [],
    /*Multidimensional array, configured CSV:
    [
        [
            'first name', 'surname', ...
        ],
        [
            'first name', 'surname', ...
        ]
    ]
    */
    multiArray: [],
    //Creates a preview of the CSV configuration
    preview: function() {
        if (document.getElementById('password-checkbox').checked) {
            document.getElementById('password').disabled = true;
        } else {
            document.getElementById('password').disabled = false;
        }
        var cache = this.inputArray[0].split(document.getElementById('spacer').value);
        if (document.getElementById('teachers').checked) {
            var group = 'Lehrer';
        } else if (document.getElementById('students').checked) {
            var group = 'Schüler';
        }
        var cn = cache[(parseInt(document.getElementById('givenname').value) - 1)] + '.' + cache[(parseInt(document.getElementById('sn').value) - 1)];
        cn = removeDiacritics(cn);
        document.getElementById('cn-pre').innerHTML = cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
        document.getElementById('givenname-pre').innerHTML = cache[(parseInt(document.getElementById('givenname').value) - 1)] || '';
        document.getElementById('sn-pre').innerHTML = cache[(parseInt(document.getElementById('sn').value) - 1)] || '';
        if (document.getElementById('teachers').checked) {
            document.getElementById('home-pre').innerHTML = '/home/teachers/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
        } else {
            document.getElementById('home-pre').innerHTML = '/home/students/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
        }
        document.getElementById('group-pre').innerHTML = group || '';
        document.getElementById('class-pre').innerHTML = cache[(parseInt(document.getElementById('class').value) - 1)] || '';
        document.getElementById('mail-pre').innerHTML = cache[(parseInt(document.getElementById('mail').value) - 1)] || '';
        document.getElementById('gebdat-pre').innerHTML = this.parse.convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)], false) || '';
        if (document.getElementById('password-checkbox').checked) {
            document.getElementById('password-pre').innerHTML = this.parse.convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)], true) || '';
        } else {
            document.getElementById('password-pre').innerHTML = cache[(parseInt(document.getElementById('password').value) - 1)] || '';
        }
    },
    //General parsing functions
    parse: {
        //Converts the configured date to the wished format
        convertDate: function(input, passwd) {
            if (document.getElementById('dspacer-1').value == document.getElementById('dspacer-2').value) {
                var inputDateOne = input.split(document.getElementById('dspacer-1').value);
                if (document.getElementById('two').value == '1') {
                    var day = inputDateOne[1];
                } else if (document.getElementById('two').value == '2') {
                    var month = inputDateOne[1];
                } else if (document.getElementById('two').value == '3') {
                    var year = inputDateOne[1];
                }
                if (document.getElementById('three').value == '1') {
                    var day = inputDateOne[2];
                } else if (document.getElementById('three').value == '2') {
                    var month = inputDateOne[2];
                } else if (document.getElementById('three').value == '3') {
                    var year = inputDateOne[2];
                }
            } else {
                var inputDateOne = input.split(document.getElementById('dspacer-1').value);
                var inputDateTwo = inputDateOne[1].split(document.getElementById('dspacer-2').value);
                if (document.getElementById('two').value == '1') {
                    var day = inputDateTwo[0];
                } else if (document.getElementById('two').value == '2') {
                    var month = inputDateTwo[0];
                } else if (document.getElementById('two').value == '3') {
                    var year = inputDateTwo[0];
                }
                if (document.getElementById('three').value == '1') {
                    var day = inputDateTwo[1];
                } else if (document.getElementById('three').value == '2') {
                    var month = inputDateTwo[1];
                } else if (document.getElementById('three').value == '3') {
                    var year = inputDateTwo[1];
                }
            }
            if (document.getElementById('one').value == '1') {
                var day = inputDateOne[0];
            } else if (document.getElementById('one').value == '2') {
                var month = inputDateOne[0];
            } else if (document.getElementById('one').value == '3') {
                var year = inputDateOne[0];
            }
            if (day.length == 1) {
                var zeroedDay = '0' + day;
            } else {
                var zeroedDay = day;
            }
            if (month.length == 1) {
                var zeroedMonth = '0' + month;
            } else {
                var zeroedMonth = month;
            }
            if (passwd) {
				return zeroedDay + '' + zeroedMonth + '' + year;
			} else {
				return zeroedDay + '.' + zeroedMonth + '.' + year;
			}
        },
        //Creates the multidimensional array after the CSV configuration
        toMultiArray: function() {
            for (var i = 0; i < csv.inputArray.length; i++) {
                if (csv.inputArray[i] != '') {
                    var cache = csv.inputArray[i].split(document.getElementById('spacer').value);
                    var thisLine = [];
                    thisLine[0] = cache[(parseInt(document.getElementById('sn').value) - 1)] || '';
                    thisLine[1] = cache[(parseInt(document.getElementById('givenname').value) - 1)] || '';
                    var cn = cache[(parseInt(document.getElementById('givenname').value) - 1)] + '.' + cache[(parseInt(document.getElementById('sn').value) - 1)];
                    cn = removeDiacritics(cn);
                    thisLine[2] = cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
                    if (document.getElementById('teachers').checked) {
                        thisLine[3] = '/home/teachers/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
                    } else {
                        thisLine[3] = '/home/students/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
                    }
                    thisLine[4] = cache[(parseInt(document.getElementById('mail').value) - 1)] || '';
                    thisLine[5] = cache[(parseInt(document.getElementById('class').value) - 1)] || '';
                    if (document.getElementById('teachers').checked) {
                        thisLine[6] = 'teachers';
                    } else if (document.getElementById('students').checked) {
                        thisLine[6] = 'students';
                    }
                    thisLine[7] = this.convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)], false) || '';
                    if (document.getElementById('password-checkbox').checked) {
                        thisLine[8] = this.convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)], true) || '';
                    } else {
                        thisLine[8] = cache[(parseInt(document.getElementById('password').value) - 1)] || '';
                    }
                    csv.multiArray.push(thisLine);
                }
            }
        },
        //Creates a editable table with all users
        createTable: function(target) {
            var table = '';
            for (var c = 0; c < csv.multiArray.length; c++) {
                if ((c%2) == 0) {
                    var cache = '<tr>';
                } else {
                    var cache = '<tr class="alt">';
                }
                for (var d = -1; d < 9; d++) {
                    if (d == 6) {
                        if (csv.multiArray[c][d] == 'teachers') {
                            cache += '<td>Lehrer</td>';
                        } else if (csv.multiArray[c][d] == 'students') {
                            cache += '<td>Schüler</td>';
                        }
                    } else if (d == 2 || d == 3) {
                        cache += '<td>'+csv.multiArray[c][d]+'</td>';
                    } else if (d == -1) {
                        cache += '<td id="icon-'+c+'"><i class="f7-icons" style="color: gray;">time</i></td>';
                    } else {
                        cache += '<td id="'+c+'-'+d+'"><p onclick="csv.inline.change('+c+', '+d+', \''+target+'\')">'+csv.multiArray[c][d]+'</p></td>';
                    }
                }
                cache += '</tr>';
                table += cache;
                console.log(c);
            }
            console.log('PRE');
            document.getElementById(target).innerHTML = table;
            console.log('POST');
        },
    },
    //Inline editing functions
    inline: {
        //Creates edit box
        change: function(c, d, target) {
            document.getElementById(c+'-'+d).innerHTML = '<input id="'+c+'.'+d+'" type="text" value="'+csv.multiArray[c][d]+'" onchange="csv.inline.save('+c+', '+d+')" onblur="csv.parse.createTable(\''+target+'\')"/>';
        },
        //Saves changed value
        save: function(c, d) {
            csv.multiArray[c][d] = document.getElementById(c+'.'+d).value;
            var cn = csv.multiArray[c][1] + '.' + csv.multiArray[c][0];
            csv.multiArray[c][2] = cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            if (csv.multiArray[c][6] == 'teachers') {
                csv.multiArray[c][3] = '/home/teachers/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            } else if (csv.multiArray[c][6] == 'students') {
                csv.multiArray[c][3] = '/home/students/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            }
        }
    },
    //Import (add user) functions
    import: {
        request: null,
        counter: 0,
        error: 0,
        callback: null,
        //Import the multidimensional array
        doMulti: function(home) {
            swal({
                title: 'CSV importieren?',
                showCancelButton: true,
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Importieren",
                cancelButtonText: "Abbrechen",
                allowOutsideClick: false,
                allowEscapeKey: false,
                type: 'question',
            }).then(function() {
                csv.import.callback = csv.import.multiCallback;
                csv.import.send(csv.multiArray[csv.import.counter], home);
            })
        },
        //Callback
        multiCallback: function(result) {
            var response = JSON.parse(result);
            var harderror = false;
            if (response.addaccount == "SUCCESS") {
                document.getElementById('icon-'+this.counter).innerHTML = '<i class="f7-icons" style="color: green;">check_round</i>';
            } else if (response.addaccount == "ERR_ADD_OBJECT") {
                this.error++;
                document.getElementById('icon-'+this.counter).innerHTML = '<i class="f7-icons" style="color: red;">bolt_round</i>';
            } else if (response.addaccount == "ERR_ADD_TO_GROUP") {
                this.error++;
                document.getElementById('icon-'+this.counter).innerHTML = '<i class="f7-icons" style="color: red;">persons_fill</i>';
                importCounter++;
            } else if (response.addaccount == "ERR_UPDATE_UID") {
                this.error++;
                this.counter++;
                harderror = true;
                document.getElementById('icon-'+this.counter).innerHTML = '<i class="f7-icons" style="color: red;">bolt_round</i>';
                swal({
                    title: "Es ist ein schwerwiegender Fehler aufgetreten.",
                    text: "WARNUNG: " + this.counter + " Nutzer wurde hinzugrfügt, jedoch konnte die User-ID nicht erhöht werden. Dies wird zu Sicherheitsproblemen führen, sollten Sie einen weiteren Nutzer hinzufügen! Der CSV-Import wurde abgebrochen.",
                    type: "error",
                })
            } else if (response.addaccount == "ERR_CREATE_HOME" || response.addaccount == "ERR_HOME_GROUP" || response.addaccount == "ERR_HOME_USER") {
                this.error++;
                document.getElementById('icon-'+this.counter).innerHTML = '<i class="f7-icons" style="color: red;">folder_fill</i>';
            } else {
                this.error++;
                document.getElementById('icon-'+this.counter).innerHTML = '<i class="f7-icons" style="color: red;">bolt_round</i>';
            }
            if (!harderror) {
                if (this.counter < (csv.multiArray.length - 1)) {
                    this.counter++;
                    this.send(csv.multiArray[this.counter]);
                } else {
                    if (this.error <= 0) {
                        swal({
                            title: 'Import erfolgreich.',
                            text: 'Alle Nutzer wurden erfolgreich importiert.',
                            type: 'success',
                        }).then(function() {
                            window.location.href = 'index.php';
                        })
                    } else {
                        swal({
                            title: 'Achtung.',
                            text: 'Es sind bei '+this.error+' Nutzern Fehler aufgetreten. Bitte überprüfen Sie diese Fehler, bevor Sie fortfahren.',
                            type: 'error',
                        })
                    }
                }
            }
        },
        //Send request
        send: function(data, home) {
            if (home) {
                var createHome = '1';
            } else {
                var createHome = '0';
            }
            this.request = getAjaxRequest();
            var url = "../api/api.php";
            var params = 'request=' + JSON.stringify({
                addaccount: {
                    givenname: data[1],
                    sn: data[0],
                    home: data[3],
                    userclass: data[5],
                    cn: data[2],
                    group: data[6],
                    gebdat: data[7],
                    email: data[4],
                    createhome: createHome,
                    passwd: data[8],
                },
            });
            this.request.onreadystatechange = this.got.bind(this);
            this.request.open("POST",url,true);
            this.request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            this.request.setRequestHeader("Content-length", params.length);
            this.request.setRequestHeader("Connection", "close");
            this.request.send(params);
        },
        //Request response
        got: function() {
            if (this.request.readyState == 4) {
                this.callback(this.request.responseText);
            }
        }
    },
    load: function() {
        this.inputArray = document.getElementById('csv').value.replace(/\r\n/g, '\n').split('\n');
        this.preview();
    }
}