<div class="loader-background loader-invisible" id="loader-background">
    <div class="loader-container">
        <table class="loader-table">
            <tr>
                <td><div class="loader"></div></td>
            </tr>
            <tr>
                <td class="loader-text" id="loader-text">SPEICHERN</td>
            </tr>
        </table>
    </div>
</div>