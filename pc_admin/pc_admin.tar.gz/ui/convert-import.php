<!DOCTYPE html>
<?php
    $page = "Jahrgangsübergang";
    include "../api/dbconnect.php";
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '' || ($_SESSION['timeout'] + 1200) < time()) {
        header("Location: nologin.php");
    } elseif ($_SESSION['type'] != '1' && $_SESSION['type'] != '2') {
        header("Location: restricted.php");
    } else {
        $_SESSION['timeout'] = time();
        include "menue.php";
    }
?>
<html lang="de">
<head>
    <title>Jahrgangsübergang Schritt 1 - PhilleConnect Admin</title>
    <?php include "includes.php"; ?>
</head>
<body>
    <?php include "assets/preloader.php"; ?>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
        <?php include "assets/timeout.php"; ?>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px; margin: 0;"><b>JAHRGANGS</b>ÜBERGANG IMPORT</p>
        <p>Work in progress - coming soon!</p>
    </div>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        var inputArray = [];
        var importCounter = 0;
        function goBack() {
            window.location.href = 'index.php';
        }
        function getAjaxRequest() {
            var ajax = null;
            ajax = new XMLHttpRequest;
            return ajax;
        }
        function loadCsv() {
            inputArray = document.getElementById('csv').value.replace(/\r\n/g, '\n').split('\n');
            doCsvPrecalc();
        }
        function convertDate(input) {
            if (document.getElementById('dspacer-1').value == document.getElementById('dspacer-2').value) {
                var inputDateOne = input.split(document.getElementById('dspacer-1').value);
                if (document.getElementById('two').value == '1') {
                    var day = inputDateOne[1];
                } else if (document.getElementById('two').value == '2') {
                    var month = inputDateOne[1];
                } else if (document.getElementById('two').value == '3') {
                    var year = inputDateOne[1];
                }
                if (document.getElementById('three').value == '1') {
                    var day = inputDateOne[2];
                } else if (document.getElementById('three').value == '2') {
                    var month = inputDateOne[2];
                } else if (document.getElementById('three').value == '3') {
                    var year = inputDateOne[2];
                }
            } else {
                var inputDateOne = input.split(document.getElementById('dspacer-1').value);
                var inputDateTwo = inputDateOne[1].split(document.getElementById('dspacer-2').value);
                if (document.getElementById('two').value == '1') {
                    var day = inputDateTwo[0];
                } else if (document.getElementById('two').value == '2') {
                    var month = inputDateTwo[0];
                } else if (document.getElementById('two').value == '3') {
                    var year = inputDateTwo[0];
                }
                if (document.getElementById('three').value == '1') {
                    var day = inputDateTwo[1];
                } else if (document.getElementById('three').value == '2') {
                    var month = inputDateTwo[1];
                } else if (document.getElementById('three').value == '3') {
                    var year = inputDateTwo[1];
                }
            }
            if (document.getElementById('one').value == '1') {
                var day = inputDateOne[0];
            } else if (document.getElementById('one').value == '2') {
                var month = inputDateOne[0];
            } else if (document.getElementById('one').value == '3') {
                var year = inputDateOne[0];
            }
            if (day.length == 1) {
                var zeroedDay = '0' + day;
            } else {
                var zeroedDay = day;
            }
            if (month.length == 1) {
                var zeroedMonth = '0' + month;
            } else {
                var zeroedMonth = month;
            }
            return zeroedDay + '.' + zeroedMonth + '.' + year;
        }
        function doCsvPrecalc() {
            var cache = inputArray[0].split(document.getElementById('spacer').value);
            if (document.getElementById('teachers').checked) {
                var group = 'Lehrer';
            } else if (document.getElementById('students').checked) {
                var group = 'Schüler';
            }
            var cn = cache[(parseInt(document.getElementById('givenname').value) - 1)] + '.' + cache[(parseInt(document.getElementById('sn').value) - 1)];
            document.getElementById('cn-pre').innerHTML = cn.toLowerCase().replace('ü', 'ue').replace('ö', 'oe').replace('ä', 'ae').replace('ß', 'ss');
            document.getElementById('givenname-pre').innerHTML = cache[(parseInt(document.getElementById('givenname').value) - 1)] || '';
            document.getElementById('sn-pre').innerHTML = cache[(parseInt(document.getElementById('sn').value) - 1)] || '';
            document.getElementById('home-pre').innerHTML = '/home/' + cn.toLowerCase().replace('ü', 'ue').replace('ö', 'oe').replace('ä', 'ae').replace('ß', 'ss');
            document.getElementById('group-pre').innerHTML = group || '';
            document.getElementById('class-pre').innerHTML = cache[(parseInt(document.getElementById('class').value) - 1)] || '';
            document.getElementById('mail-pre').innerHTML = cache[(parseInt(document.getElementById('mail').value) - 1)] || '';
            document.getElementById('gebdat-pre').innerHTML = convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)]) || '';
        }
        function doImport() {
            swal({
                title: 'CSV importieren?',
                showCancelButton: true,
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Importieren",
                cancelButtonText: "Abbrechen",
                closeOnConfirm: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                type: 'question'
            }).then(function() {
                swal.disableButtons();
                doSend();
            })
        }
        function doSend() {
            if (document.getElementById('teachers').checked) {
                var group = 'teachers';
            } else {
                var group = 'students';
            }
            request = getAjaxRequest();
            var cache = inputArray[importCounter].split(document.getElementById('spacer').value);
            var cn = cache[(parseInt(document.getElementById('givenname').value) - 1)] + '.' + cache[(parseInt(document.getElementById('sn').value) - 1)];
            var url = "../api/temp-db.php";
            var givenname = cache[(parseInt(document.getElementById('givenname').value) - 1)] || '';
            var sn = cache[(parseInt(document.getElementById('sn').value) - 1)] || '';
            var home = '/home/' + cn.toLowerCase().replace('ü', 'ue').replace('ö', 'oe').replace('ä', 'ae').replace('ß', 'ss');
            var classVar = cache[(parseInt(document.getElementById('class').value) - 1)] || '';
            var cn = cn.toLowerCase().replace('ü', 'ue').replace('ö', 'oe').replace('ä', 'ae').replace('ß', 'ss');
            var gebdat = convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)]) || '';
            var mail = cache[(parseInt(document.getElementById('mail').value) - 1)] || '';
            var params = "givenname="+givenname+"&sn="+sn+"&home="+home+"&class="+classVar+"&cn="+cn+"&group="+group+"&gebdat="+gebdat+"&email="+mail;
            request.onreadystatechange=stateChangedSave;
            request.open("POST",url,true);
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            request.setRequestHeader("Content-length", params.length);
            request.setRequestHeader("Connection", "close");
            request.send(params);
            function stateChangedSave() {
                if (request.readyState == 4) {
                    if (request.responseText == "success") {
                        if (importCounter < (inputArray.length - 1)) {
                            importCounter++;
                            doSend();
                        } else {
                            finishImport();
                        }
                    } else if (request.responseText == "add_error") {
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen. " + importCounter + " Nutzer sind bereits importiert.",
                            type: "error",
                        })
                    } else if (request.responseText == "group_error") {
                        importCounter++;
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen. " + importCounter + " Nutzer sind bereits importiert, 1 Nutzer ist teilweise importiert.",
                            type: "warning",
                        })
                    } else if (request.responseText == "update_error") {
                        importCounter++;
                        swal({
                            title: "Es ist ein schwerwiegender Fehler aufgetreten.",
                            text: "WARNUNG: " + importCounter + " Nutzer wurde hinzugrfügt, jedoch konnte die User-ID nicht erhöht werden. Dies wird zu Sicherheitsproblemen führen, sollten Sie einen weiteren Nutzer hinzufügen!",
                            type: "error",
                        })
                    } else if (request.responseText == "homefolder_error") {
                        swal({
                            title: "Es kommte kein Home-Ordner angelegt werden.",
                            text: "Anscheinend kann PHP nicht in /home/teachers und /home/students schreiben. Bitte lege den Ordner manuell an.",
                            type: "error",
                        })
                    } else {
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen. " + importCounter + " Nutzer sind bereits importiert.",
                            type: "error",
                        })
                    }
                }
            }
        }
        function finishImport() {
            swal({
                title: 'CSV erfolgreich importiert',
                type: 'success',
            }).then(function() {
                window.location.href = 'convert-compare.php';
            })
        }
    </script>
</body>
</html>