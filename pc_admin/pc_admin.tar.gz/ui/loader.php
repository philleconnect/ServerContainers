<div class="loader-container">
    <div class="loader"></div>
    <p class="text"></p>
</div>