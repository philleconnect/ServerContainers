<!DOCTYPE html>
<?php
    $page = "Gruppenlaufwerke";
    include "../api/dbconnect.php";
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '' || ($_SESSION['timeout'] + 1200) < time()) {
        header("Location: nologin.php");
    } elseif ($_SESSION['type'] != '1' && $_SESSION['type'] != '3') {
        header("Location: restricted.php");
    } else {
        $_SESSION['timeout'] = time();
        include "menue.php";
    }
?>
<html lang="de">
<head>
    <title>Gruppenlaufwerke - PhilleConnect Admin</title>
    <?php include "includes.php"; ?>
</head>
<body>
    <?php include "assets/preloader.php"; ?>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
        <?php include "assets/timeout.php"; ?>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px; text-transform: uppercase;"><b>GRUPPEN</b>LAUFWERKE</p>
        <div class="datagrid">
            <table id="groupfolders">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Pfad</th>
                        <th>Zugriff Schüler</th>
                        <th>Zugriff Lehrer</th>
                        <th>Schreibzugriff</th>
                        <th>Aktion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $request = "SELECT * FROM groupfolders";
                        $query = mysqli_query($database, $request);
                        $style = false;
                        while ($response = mysqli_fetch_assoc($query)) {
                            if ($style) {
                    ?>
                    <tr class="alt">
                    <?php
                                $style = false;
                            } else {
                    ?>
                    <tr>
                    <?php
                                $style = true;
                            }
                    ?>
                        <td><?php echo $response['name']; ?></td>
                        <td><?php echo $response['path']; ?></td>
                    <?php
                            if ($response['students'] == 1) {
                    ?>
                        <td><input type="checkbox" id="" checked/></td>
                    <?php
                            } else {
                    ?>
                        <td><input type="checkbox" id=""/></td>
                    <?php
                            }
                    ?>
                    <?php
                            if ($response['teachers'] == 1) {
                    ?>
                        <td><input type="checkbox" id="" checked/></td>
                    <?php
                            } else {
                    ?>
                        <td><input type="checkbox" id=""/></td>
                    <?php
                            }
                    ?>
                    <?php
                            if ($response['writeable'] == 1) {
                    ?>
                        <td><input type="checkbox" id="" checked/></td>
                    <?php
                            } else {
                    ?>
                        <td><input type="checkbox" id=""/></td>
                    <?php
                            }
                    ?>
                        <td><a onclick="changeGroupFolder(<?php echo $response['id']; ?>)">Bearbeiten</a></td>
                    </tr>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </div>
        <button onclick="addGroupFolder()">Neues Gruppenlaufwerk anlegen</button>
    </div>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        function addGroupFolder() {
            window.location.href = 'newgroupfolder.php';
        }
        function changeGroupFolder(id) {
            window.location.href = 'changegroupfolder.php?id='+id;
        }
    </script>
</body>
</html>
