<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="ressources/css/main.css" type="text/css">
<link rel="stylesheet" href="ressources/css/table.css" type="text/css">
<link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
<link rel="stylesheet" href="ressources/css/framework7-icons.css" type="text/css">
<link rel="stylesheet" href="ressources/css/preloader.css" type="text/css">
<script src="ressources/js/responsive-nav.min.js"></script>
<script src="ressources/js/jquery.min.js"></script>
<script src="ressources/js/swal.min.js"></script>
<script src="ressources/js/sort.min.js"></script>
<script src="ressources/js/preloader.js"></script>
<script src="ressources/js/accents.js"></script>
<script src="ressources/js/csv.js"></script>
<meta name="robots" content="noindex">