# Rechnerverwaltung
This is the web bases administration backend and client application API of PhilleConnect.

# How to use this?
This requires a webserver with PHP and a MySQL/MariaDB server. To use the user account management, it requires a LDAP server. To use the internet access control, your network router must be an IPFire.
