-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 07, 2017 at 03:28 PM
-- Server version: 5.5.54-0+deb8u1
-- PHP Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `philleconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `configs`
--

CREATE TABLE IF NOT EXISTS `configs` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf8_bin NOT NULL,
  `os` text COLLATE utf8_bin NOT NULL,
  `smbserver` text COLLATE utf8_bin NOT NULL,
  `driveone` text COLLATE utf8_bin NOT NULL,
  `drivetwo` text COLLATE utf8_bin NOT NULL,
  `drivethree` text COLLATE utf8_bin NOT NULL,
  `pathone` text COLLATE utf8_bin NOT NULL,
  `pathtwo` text COLLATE utf8_bin NOT NULL,
  `paththree` text COLLATE utf8_bin NOT NULL,
  `shutdown` int(11) NOT NULL,
  `dologin` text COLLATE utf8_bin NOT NULL,
  `loginpending` text COLLATE utf8_bin NOT NULL,
  `loginfailed` text COLLATE utf8_bin NOT NULL,
  `wrongcredentials` text COLLATE utf8_bin NOT NULL,
  `networkfailed` text COLLATE utf8_bin NOT NULL,
  `success` text COLLATE utf8_bin NOT NULL,
  `groupfolders` text COLLATE utf8_bin NOT NULL,
  `infotext` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `configs`
--

INSERT INTO `configs` (`id`, `name`, `os`, `smbserver`, `driveone`, `drivetwo`, `drivethree`, `pathone`, `pathtwo`, `paththree`, `shutdown`, `dologin`, `loginpending`, `loginfailed`, `wrongcredentials`, `networkfailed`, `success`, `groupfolders`, `infotext`) VALUES
(1, 'test_win', 'win', 'devserver.fritz.box', 'X:', 'Y:', 'Z:', 'Laufwerk X', 'Laufwerk Y', 'Laufwerk Z', 540, 'Bitte melde dich mit deinen Zugangsdaten an.', 'Anmeldung läuft, bitte warten...', 'Anmeldung fehlgeschlagen. Bitte frage deinen Lehrer.', 'Nutzername oder Passwort falsch.', 'Nutzername falsch oder Netzwerkfehler.', 'Anmeldung erfolgreich!', '[["J:","SchulTausch"],["K:","RaumTausch/K15"],["L:","SchulVorlagen"]]', 'Testhinweis%Testabsatz'),
(2, 'test_linux', 'linux', 'devserver.fritz.box', '/media/', '/media/', '/media/', '/media/', '/media/', '/media/', 540, 'Bitte melde dich mit deinen Zugangsdaten an.', 'Anmeldung läuft, bitte warten...', 'Anmeldung fehlgeschlagen. Bitte frage deinen Lehrer.', 'Nutzername oder Passwort falsch.', 'Nutzername falsch oder Netzwerkfehler.', 'Anmeldung erfolgreich!', '[["/media/","SchulTausch"],["/media/","RaumTausch/K15"],["/media/","SchulVorlagen"]]', 'Testhinweis%Testabsatz');

-- --------------------------------------------------------

--
-- Table structure for table `machines`
--

CREATE TABLE IF NOT EXISTS `machines` (
`id` int(11) NOT NULL,
  `room` text COLLATE utf8_bin NOT NULL,
  `machine` text COLLATE utf8_bin NOT NULL,
  `hardwareid` text COLLATE utf8_bin NOT NULL,
  `config_win` text COLLATE utf8_bin NOT NULL,
  `config_linux` text COLLATE utf8_bin NOT NULL,
  `inet` int(11) NOT NULL,
  `ip` text COLLATE utf8_bin NOT NULL,
  `ipfire` int(11) NOT NULL,
  `teacher` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Table structure for table `site`
--

CREATE TABLE IF NOT EXISTS `site` (
`id` int(11) NOT NULL,
  `value` text COLLATE utf8_bin NOT NULL,
  `data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `site`
--

INSERT INTO `site` (`id`, `value`, `data`) VALUES
(1, 'menu', '[["Accounts","index.php",[["Nutzer hinzufügen","newuser.php"],["CSV importieren","csvimport.php"],["Jahrgangsübergang","convert-import.php"]]],["Konfigurationsprofile","config.php"],["Rechnerverwaltung","machines.php"],["Grundkonfiguration","maincfg.php"],["Logout","logout.php"]]'),
(2, 'ipfireurl', 'ipfire-test.ipfire'),
(3, 'globalPw', 'jdhbvhcjnudsji3uhdKJkjBHnhehu3zrgvf'),
(4, 'ldapurl', 'localhost'),
(5, 'ldapadmin', 'LDAPADMIN'),
(6, 'admindn', 'cn=admin,dc=example,dc=com'),
(7, 'usersdn', 'ou=users,dc=example,dc=com'),
(8, 'groupsdn', 'ou=groups,dc=example,dc=com'),
(9, 'teachergroup', 'cn=teachers'),
(10, 'studentgroup', 'cn=students'),
(11, 'ipfireuser', 'root'),
(12, 'pubkey', '/var/www/.ssh/id_rsa.pub'),
(13, 'rsafile', '/var/www/.ssh/id_rsa'),
(14, 'lastUid', '20000');

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE IF NOT EXISTS `userdata` (
`id` int(11) NOT NULL,
  `username` text COLLATE utf8_bin NOT NULL,
  `password` text COLLATE utf8_bin NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`id`, `username`, `password`, `type`) VALUES
(1, 'jkreutz', '86a61784292ebd1517e9e2e147dde349f094e8f34235d8af030640db4bb8ad64ae6d40318ee1f2b6302099e3c068423b6fa65b130a059dffd0f391573c8633e6', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `configs`
--
ALTER TABLE `configs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `machines`
--
ALTER TABLE `machines`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site`
--
ALTER TABLE `site`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `configs`
--
ALTER TABLE `configs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `machines`
--
ALTER TABLE `machines`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `site`
--
ALTER TABLE `site`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `userdata`
--
ALTER TABLE `userdata`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
