<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } else {
        include "dbconnect.php";
        include "accessConfig.php";
        $ldapconn = ldap_connect(loadConfig('ldap', 'url'));
        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_bind($ldapconn, loadConfig('ldap', 'admindn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'password'));
        if (ldap_delete($ldapconn, "uid=".$_POST['user'].", ".loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'))) {
            $entry = array();
            $entry['memberUid'] = $_POST['user'];
            if (ldap_mod_del($ldapconn, 'cn='.$_POST['group'].', '.loadConfig('ldap', 'groupsdn').','.loadConfig('ldap', 'basedn'), $entry)) {
                echo 'success';
            } else {
                echo 'error';
            }
        } else {
            echo 'error';
        }
    }
?>