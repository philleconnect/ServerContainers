<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } else {
        if ($_SESSION['type'] == '1') {
            if ($_POST['pwd'] == $_POST['pwd2']) {
                include "dbconnect.php";
                $request = "UPDATE userdata SET password = '".mysqli_real_escape_string($database, hash('sha512', $_POST['pwd']))."' WHERE username = '".$_SESSION['user']."'";
                $query = mysqli_query($database, $request);
                if ($query) {
                    echo 'success';
                } else {
                    echo 'database_error';
                }
            } else {
                echo 'notsame';
            }
        } else {
            echo 'denied';
        }
    }
?>