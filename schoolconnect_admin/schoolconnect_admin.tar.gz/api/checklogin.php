<?php
    include 'dbconnect.php';
    $request = "SELECT password, type FROM userdata WHERE username = '".mysqli_real_escape_string($database, $_POST['uname'])."'";
    $query = mysqli_query($database, $request);
    $result = mysqli_fetch_assoc($query);
    if ($result['password'] == hash('sha512', $_POST['passwd'])) {
        session_start();
        $_SESSION['user'] = $_POST['uname'];
        $_SESSION['type'] = $result['type'];
        echo "success";
    } else {
        echo "wrongcredentials";
    }
?>