<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } else {
        include "dbconnect.php";
        if ($_POST['mode'] == 'new') {
            $request = "INSERT INTO configs (name, os, smbserver, driveone, drivetwo, drivethree, pathone, pathtwo, paththree, shutdown, dologin, loginpending, loginfailed, wrongcredentials, networkfailed, success, groupfolders, infotext) VALUES ('".mysqli_real_escape_string($database, $_POST['name'])."', '".mysqli_real_escape_string($database, $_POST['os'])."', '".mysqli_real_escape_string($database, $_POST['smbserver'])."', '".mysqli_real_escape_string($database, $_POST['driveone'])."', '".mysqli_real_escape_string($database, $_POST['drivetwo'])."', '".mysqli_real_escape_string($database, $_POST['drivethree'])."', '".mysqli_real_escape_string($database, $_POST['pathone'])."', '".mysqli_real_escape_string($database, $_POST['pathtwo'])."', '".mysqli_real_escape_string($database, $_POST['paththree'])."', '".mysqli_real_escape_string($database, $_POST['shutdown'])."', '".mysqli_real_escape_string($database, $_POST['dologin'])."', '".mysqli_real_escape_string($database, $_POST['loginpending'])."', '".mysqli_real_escape_string($database, $_POST['loginfailed'])."', '".mysqli_real_escape_string($database, $_POST['wrongcredentials'])."', '".mysqli_real_escape_string($database, $_POST['networkfailed'])."', '".mysqli_real_escape_string($database, $_POST['success'])."', '".mysqli_real_escape_string($database, $_POST['groupfolders'])."', '".mysqli_real_escape_string($database, $_POST['infotext'])."')";
        } else if ($_POST['mode'] == 'delete') {
            if ($_POST['os'] == 'win') {
                $checkInUseRequest = "SELECT COUNT(*) AS anzahl FROM machines WHERE config_win = '".mysqli_real_escape_string($database, $_POST['name'])."'";
            } else {
                $checkInUseRequest = "SELECT COUNT(*) AS anzahl FROM machines WHERE config_linux = '".mysqli_real_escape_string($database, $_POST['name'])."'";
            }
            $checkInUseQuery = mysqli_query($database, $checkInUseRequest);
            $checkInUseResult = mysqli_fetch_assoc($checkInUseQuery);
            if ($checkInUseResult['anzahl'] > 0) {
                echo 'inuse';
                die;
            } else {
                $request = "DELETE FROM configs WHERE id = '".mysqli_real_escape_string($database, $_POST['id'])."'";
            }
        } else {
            $request = "UPDATE configs SET name = '".mysqli_real_escape_string($database, $_POST['name'])."', os = '".mysqli_real_escape_string($database, $_POST['os'])."', smbserver = '".mysqli_real_escape_string($database, $_POST['smbserver'])."', driveone = '".mysqli_real_escape_string($database, $_POST['driveone'])."', drivetwo = '".mysqli_real_escape_string($database, $_POST['drivetwo'])."', drivethree = '".mysqli_real_escape_string($database, $_POST['drivethree'])."', pathone = '".mysqli_real_escape_string($database, $_POST['pathone'])."', pathtwo = '".mysqli_real_escape_string($database, $_POST['pathtwo'])."', paththree = '".mysqli_real_escape_string($database, $_POST['paththree'])."', shutdown = '".mysqli_real_escape_string($database, $_POST['shutdown'])."', dologin = '".mysqli_real_escape_string($database, $_POST['dologin'])."', loginpending = '".mysqli_real_escape_string($database, $_POST['loginpending'])."', loginfailed = '".mysqli_real_escape_string($database, $_POST['loginfailed'])."', wrongcredentials = '".mysqli_real_escape_string($database, $_POST['wrongcredentials'])."', networkfailed = '".mysqli_real_escape_string($database, $_POST['networkfailed'])."', success = '".mysqli_real_escape_string($database, $_POST['success'])."', groupfolders = '".mysqli_real_escape_string($database, $_POST['groupfolders'])."', infotext = '".mysqli_real_escape_string($database, $_POST['infotext'])."' WHERE id = ".mysqli_real_escape_string($database, $_POST['id']);
        }
        $query = mysqli_query($database, $request);
        if ($query == true) {
            echo 'success';
        } else {
            echo 'error';
        }
    }
?>