<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } else {
        include "dbconnect.php";
        if ($_POST['mode'] == 'new') {
            $request = "INSERT INTO machines (room, machine, hardwareid, ip) VALUES ('".mysqli_real_escape_string($database, $_POST['room'])."', '".mysqli_real_escape_string($database, $_POST['name'])."', '".mysqli_real_escape_string($database, $_POST['machine'])."', '".mysqli_real_escape_string($database, $_POST['ip'])."')";
        } else {
            $request = "UPDATE machines SET room = '".mysqli_real_escape_string($database, $_POST['room'])."', machine = '".mysqli_real_escape_string($database, $_POST['machine'])."', config_win = '".mysqli_real_escape_string($database, $_POST['config_win'])."', config_linux = '".mysqli_real_escape_string($database, $_POST['config_linux'])."', teacher = ".mysqli_real_escape_string($database, $_POST['teacherpc']).", inet = ".mysqli_real_escape_string($database, $_POST['inet'])." WHERE id = ".mysqli_real_escape_string($database, $_POST['id']);
        }
        $query = mysqli_query($database, $request);
        if ($query == true) {
            echo 'success';
        } else {
            echo 'error';
        }
    }
?>