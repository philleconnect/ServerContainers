<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } else {
        include "dbconnect.php";
        include "accessConfig.php";
        $ldapconn = ldap_connect(loadConfig('ldap', 'url'));
        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_bind($ldapconn, loadConfig('ldap', 'admindn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'password'));
        $entry = array();
        $salt = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 4)), 0, 4);
        $hash = '{SSHA}' . base64_encode(sha1($_POST['passwd'].$salt, TRUE).$salt);
        $sambaHash = strtoupper(bin2hex(mhash(MHASH_MD4, iconv("UTF-8","UTF-16LE",$_POST['passwd']))));
        $now = time();
        $uid = (loadConfig('ldap', 'lastuid') + 1);
        $search = ldap_search($ldapconn, loadConfig('ldap', 'basedn'), "sambaDomainName=".loadConfig('ldap', 'sambahostname'));
        $result = ldap_get_entries($ldapconn, $search);
        $entry['description'] = $_POST['gebdat'];
        $entry['businessCategory'] = $_POST['class'];
        $entry['cn'] = $_POST['cn'];
        $entry['displayName'] = $_POST['givenname'].' '.$_POST['sn'];
        $entry['gecos'] = 'System User';
        $entry['gidNumber'] = '513';
        $entry['givenName'] = $_POST['givenname'];
        $entry['homeDirectory'] = $_POST['home'];
        $entry['loginShell'] = '/bin/bash';
        $entry['mail'] = $_POST['email'];
        $entry['objectClass'] = array('top', 'person', 'organizationalPerson', 'posixAccount', 'shadowAccount', 'inetOrgPerson', 'sambaSamAccount');
        $entry['userPassword'] = $hash;
        $entry['sambaAcctFlags'] = '[U]';
        $entry['sambaHomePath'] = '\\\\\\'.$_POST['cn'];
        $entry['sambaKickoffTime'] = '2147483647';
        $entry['sambaLogoffTime'] = '2147483647';
        $entry['sambaLogonTime'] = '0';
        $entry['sambaNTPassword'] = $sambaHash;
        $entry['sambaPrimaryGroupSID'] = $result[0]['sambasid'][0].'-513';
        $entry['sambaProfilePath'] = '\\\\\\profiles\\'.$_POST['cn'];
        $entry['sambaPwdCanChange'] = '0';
        $entry['sambaPwdLastSet'] = $now;
        $entry['sambaPwdMustChange'] = '86401501080402';
        $entry['sambaSID'] = $result[0]['sambasid'][0].'-'.$uid;
        $entry['shadowLastChange'] = $now;
        $entry['shadowMax'] = '999999999';
        $entry['sn'] = $_POST['sn'];
        $entry['uidNumber'] = $uid;
        $entry['uid'] = $_POST['cn'];
        if (ldap_add($ldapconn, "uid=".$_POST['cn'].", ".loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), $entry)) {
            if (changeConfigValue('ldap', 'lastuid', $uid)) {
                $groupentry = array();
                $groupentry['memberUid'] = $_POST['cn'];
                if (ldap_mod_add($ldapconn, 'cn='.$_POST['group'].', '.loadConfig('ldap', 'groupsdn').','.loadConfig('ldap', 'basedn'), $groupentry)) {
                    /*if ($_POST['createhome'] == '1') {
                        if (mkdir($_POST['home'], 0774)) {
                            if (chown($_POST['home'], $_POST['cn'])) {
                                if (chgrp($_POST['home'], $_POST['group'])) {
                                    echo 'success';
                                } else {
                                    echo 'homefolder_error';
                                }
                            } else {
                                echo 'homefolder_error';
                            }
                        } else {
                            echo 'homefolder_error';
                        }
                    } else {*/
                        echo 'success';
                    //}
                } else {
                    echo 'group_error';
                }
            } else {
                echo 'update_error';
            }
        } else {
            echo 'add_error';
        }
    }
?>
