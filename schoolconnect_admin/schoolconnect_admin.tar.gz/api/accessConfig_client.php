<?php
    function changeConfigValue($group, $value, $newValue) {
        $data = file_get_contents('config/config.txt');
        if ($data == 'empty') {
            $config = [
                "database" => [
                    "url" => "",
                    "user" => "",
                    "password" => "",
                    "name" => "",
                    "finish" => "false",
                ],
                "ldap" => [
                    "url" => "",
                    "password" => "",
                    "basedn" => "",
                    "admindn" => "",
                    "usersdn" => "",
                    "groupsdn" => "",
                    "teacherscn" => "",
                    "studentscn" => "",
                    "sambasid" => "",
                    "lastuid" => "19999",
                    "finish" => "false",
                ],
                "ipfire" => [
                    "url" => "",
                    "user" => "",
                    "pubkey" => "/var/www/.ssh/id_rsa.pub",
                    "rsafile" => "/var/www/.ssh/id_rsa",
                    "finish" => "false",
                ],
                "globalPw" => "",
                "config" => "",
            ];
        } else {
            $config = unserialize($data);
        }
        if (is_array($config[$group])) {
            $config[$group][$value] = $newValue;
        } else {
            $config[$group] = $newValue;
        }
        if (file_put_contents('config/config.txt', serialize($config)) != false) {
            return true;
        } else {
            return false;
        }
    }
    function loadConfig($group, $value) {
        $data = file_get_contents('config/config.txt');
        if ($data != 'empty') {
            $config = unserialize($data);
            if (is_array($config[$group])) {
                return $config[$group][$value];
            } else {
                return $config[$group];
            }
        } else {
            return false;
        }
    }
?>
