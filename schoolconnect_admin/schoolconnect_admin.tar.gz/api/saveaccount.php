<?php
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        echo 'error';
    } else {
        include "dbconnect.php";
        include "accessConfig.php";
        $ldapconn = ldap_connect(loadConfig('ldap', 'url'));
        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
        $r=ldap_bind($ldapconn);
        $entry = array();
        $entry['givenName'] = $_POST['givenname'];
        $entry['sn'] = $_POST['sn'];
        $entry['homeDirectory'] = $_POST['home'];
        $entry['businessCategory'] = $_POST['class'];
        $entry['description'] = $_POST['gebdat'];
        $entry['mail'] = $_POST['email'];
        ldap_bind($ldapconn, loadConfig('ldap', 'admindn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'password'));
        if (ldap_modify($ldapconn, "uid=".$_POST['user'].", ".loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), $entry)) {
            echo 'success';
        } else {
            echo 'error';
        }
    }
?>