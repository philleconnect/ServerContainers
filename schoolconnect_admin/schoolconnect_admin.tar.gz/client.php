<?php
/*  Backend für PhilleConnect Clientprogramme
    CopyRight 2017 Johannes Kreutz. Alle Rechte vorbehalten.*/
    include "api/dbconnect_client.php";
    //lade globale Funktion, um Grundkonfigurations-Parameter zu laden
    include "api/accessConfig_client.php";
    //Globales Passwort soll sicherstellen, dass sich zwei installationen (z.B. testing und productive) im gleichen Netz nicht beeinflussen.
    if ($_POST['globalpw'] == loadConfig('globalPw', null)) {
        //Prüfen ob MAC-Addresse registriert ist
        $getCountRequest = "SELECT COUNT(*) AS anzahl FROM machines WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['machine'])."'";
        $getCountQuery = mysqli_query($database, $getCountRequest);
        $getCountResult = mysqli_fetch_assoc($getCountQuery);
        if ($getCountResult['anzahl'] > 0) {
            //Rechner ist bekannt -> Konfigurationsdatei je nach OS laden
            if ($_POST['os'] == 'win') {
                $getConfigRequest = "SELECT config_win, ip, room, machine, teacher FROM machines WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['machine'])."'";
            } else {
                $getConfigRequest = "SELECT config_linux, ip, room, machine, teacher FROM machines WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['machine'])."'";
            }
        } else if ($getCountResult['anzahl'] == 0) {
            //Rechner ist unbekannt
            echo "nomachine";
            die;
        }
        $getConfigQuery = mysqli_query($database, $getConfigRequest);
        $getConfigResult = mysqli_fetch_assoc($getConfigQuery);
        if ($_POST['ip'] != $_SERVER['REMOTE_ADDR']) {
			echo 'noaccess';
			die;
        } else {
			if ($getConfigResult['ip'] != $_POST['ip']) {
				//Gespeicherte IP aktualisieren
				$updateRequest = "UPDATE machines SET ip = '".mysqli_real_escape_string($database, $_POST['ip'])."' WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['machine'])."'";
				$updateQuery = mysqli_query($database, $updateRequest);
			}
		}
        if ($_POST['usage'] == 'userlist') {
            //Nutzerliste erzeugen und als JSON ausliefern
            $ldapconn = ldap_connect(loadConfig('ldap', 'url'));
			ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
			$r=ldap_bind($ldapconn);
			$allusers=ldap_search($ldapconn, loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), "uid=*");
			$users = ldap_get_entries($ldapconn, $allusers);
            if ($getConfigResult['teacher'] == '1') {
				$group=ldap_search($ldapconn, loadConfig('ldap', 'groupsdn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'teacherscn'));
			} else {
				$group=ldap_search($ldapconn, loadConfig('ldap', 'groupsdn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'studentscn'));
			}
            $groupcontent = ldap_get_entries($ldapconn, $group);
            $data = array();
            for ($i=0; $i<$users['count']; $i++) {
				if (in_array($users[$i]['cn'][0], $groupcontent[0]['memberuid'])) {
					$parameter = array($users[$i]['displayname'][0], $users[$i]['displayname'][0], $users[$i]['cn'][0]);
					array_push($data, $parameter);
				}
			}
            $data = (object)$data;
            echo json_encode($data);
        } elseif ($_POST['usage'] == 'login') {
            //Login. Internet sperren, falls nötig
            if ($_POST['os'] == 'win') {
                $request = "SELECT inet FROM configs WHERE name = '".mysqli_real_escape_string($database, $getConfigResult['config_win'])."'";
            } else {
                $request = "SELECT inet FROM configs WHERE name = '".mysqli_real_escape_string($database, $getConfigResult['config_linux'])."'";
            }
            $query = mysqli_query($database, $request);
            $response = mysqli_fetch_assoc($query);
            if ($response['inet'] == 0) {
                $inetQuery = "UPDATE machines SET inet = 0 WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['machine'])."'";
                $inetQuery = mysqli_query($database, $request);
                $request = "SELECT machine, ip, ipfire FROM machines";
				$query = mysqli_query($database, $request);
				$customhosts = fopen("customhosts", "w");
				$customgroups = fopen("customgroups", "w");
				$counter = 1;
				while ($result = mysqli_fetch_assoc($query)) {
					fwrite($customhosts, $counter.",".$result['machine'].",ip,".$result['ip']."/255.255.255.255\n");
					if ($result['ipfire'] == 0) {
						fwrite($customgroups, $counter.",blocked,,".$result['machine'].",Custom Host\n");
					}
					$counter++;
				}
				fclose($customhosts);
				fclose($customgroups);
                //Dateien per SCP auf IPFire kopieren und per SSH neu laden
				$connection = ssh2_connect(loadConfig('ipfire', 'url'), 22);
				ssh2_auth_pubkey_file($connection, loadConfig('ipfire', 'user'), loadConfig('ipfire', 'pubkey'), loadConfig('ipfire', 'rsafile'));
				ssh2_scp_send($connection, 'customhosts', '/var/ipfire/fwhosts/customhosts', 0644);
				ssh2_scp_send($connection, 'customgroups', '/var/ipfire/fwhosts/customgroups', 0644);
				ssh2_exec($connection, '/usr/local/bin/firewallctrl');
            }
            //Login
            $ldapconn = ldap_connect(loadConfig('ldap', 'url'));
			ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
			$r=ldap_bind($ldapconn);
			$allusers=ldap_search($ldapconn, loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), "uid=".$_POST['uname']);
			$users = ldap_get_entries($ldapconn, $allusers);
            if ($getConfigResult['teacher'] == '1') {
				$group=ldap_search($ldapconn, loadConfig('ldap', 'groupsdn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'teacherscn'));
			} else {
				$group=ldap_search($ldapconn, loadConfig('ldap', 'groupsdn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'studentscn'));
			}
            $groupcontent = ldap_get_entries($ldapconn, $group);
            if ($users['count'] < 1) {
				echo '2';
			} else {
				if (in_array($users[0]['cn'][0], $groupcontent[0]['memberuid'])) {
					if (@ldap_bind($ldapconn, 'uid='.$_POST['uname'].','.loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), $_POST['password'])) {
						echo '0';
					} else {
						echo '1';
					}
				} else {
					echo '2';
				}
			}
        } elseif ($_POST['usage'] == 'pwchange') {
			//Nutzerpasswort ändern
			$ldapconn = ldap_connect(loadConfig('ldap', 'url'));
			ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
			$r=ldap_bind($ldapconn);
			$allusers=ldap_search($ldapconn, loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), "uid=".$_POST['uname']);
			$users = ldap_get_entries($ldapconn, $allusers);
            if ($users['count'] < 1) {
				echo 'error';
			} else {
				if (@ldap_bind($ldapconn, 'uid='.$_POST['uname'].','.loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), $_POST['oldpw'])) {
					if ($_POST['newpw'] == $_POST['newpw2']) {
						$salt = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 4)), 0, 4);
						$hash = '{SSHA}' . base64_encode(sha1($_POST['newpw'].$salt, TRUE).$salt);
						$sambaHash = strtoupper(bin2hex(mhash(MHASH_MD4, iconv("UTF-8","UTF-16LE",$_POST['newpw']))));
						$now = time();
						$entry = array();
						$entry['userPassword'] = $hash;
						$entry['sambaNTPassword'] = $sambaHash;
						$entry['sambaPwdLastSet'] = $now;
						ldap_bind($ldapconn, loadConfig('ldap', 'admindn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'password'));
						if (ldap_modify($ldapconn, "uid=".$_POST['uname'].", ".loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), $entry)) {
							echo 'success';
						} else {
							echo 'error';
						}
					} else {
						echo 'notsame';
					}
				} else {
					echo 'wrongold';
				}
			}
		} elseif ($_POST['usage'] == 'pwreset') {
			//Schülerpasswort mit Lehrerrechten zurücksetzen
			if ($getConfigResult['teacher'] == '1') {
				$ldapconn = ldap_connect(loadConfig('ldap', 'url'));
				ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
				$r=ldap_bind($ldapconn);
				$allusers=ldap_search($ldapconn, loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), "uid=".$_POST['teacheruser']);
				$users = ldap_get_entries($ldapconn, $allusers);
				$group=ldap_search($ldapconn, loadConfig('ldap', 'groupsdn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'teacherscn'));
				$groupcontent = ldap_get_entries($ldapconn, $group);
				if ($users['count'] < 1) {
					echo 'error';
				} else {
					if (in_array($users[0]['cn'][0], $groupcontent[0]['memberuid'])) {
						$nallusers=ldap_search($ldapconn, loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), "uid=".$_POST['uname']);
						$nusers = ldap_get_entries($ldapconn, $nallusers);
						if (in_array($nusers[0]['cn'][0], $groupcontent[0]['memberuid'])) {
							echo 'notallowed';
						} else {
							if (@ldap_bind($ldapconn, 'uid='.$_POST['teacheruser'].','.loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), $_POST['teacherpw'])) {
								if ($_POST['newpw'] == $_POST['newpw2']) {
									$salt = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 4)), 0, 4);
									$hash = '{SSHA}' . base64_encode(sha1($_POST['newpw'].$salt, TRUE).$salt);
									$sambaHash = strtoupper(bin2hex(mhash(MHASH_MD4, iconv("UTF-8","UTF-16LE",$_POST['newpw']))));
									$now = time();
									$entry = array();
									$entry['userPassword'] = $hash;
									$entry['sambaNTPassword'] = $sambaHash;
									$entry['sambaPwdLastSet'] = $now;
									ldap_bind($ldapconn, loadConfig('ldap', 'admindn').','.loadConfig('ldap', 'basedn'), loadConfig('ldap', 'password'));
									if (ldap_modify($ldapconn, "uid=".$_POST['uname'].", ".loadConfig('ldap', 'usersdn').','.loadConfig('ldap', 'basedn'), $entry)) {
										echo 'success';
									} else {
										echo 'error';
									}
								} else {
									echo 'notsame';
								}
							} else {
								echo 'wrongteacher';
							}
						}
					} else {
						echo 'noteacher';
					}
				}
			} else {
				echo 'noaccess';
			}
		} elseif ($_POST['usage'] == 'notices') {
            //Notizen ausliefern
            if ($_POST['os'] == 'win') {
                $request = "SELECT infotext FROM configs WHERE name = '".mysqli_real_escape_string($database, $getConfigResult['config_win'])."'";
            } else {
                $request = "SELECT infotext FROM configs WHERE name = '".mysqli_real_escape_string($database, $getConfigResult['config_linux'])."'";
            }
            $query = mysqli_query($database, $request);
            $result = mysqli_fetch_assoc($query);
            echo $result['infotext'];
        } elseif ($_POST['usage'] == 'config') {
            //Konfiguration auswerten und als JSON ausliefern
            if ($_POST['os'] == 'win') {
				if ($getConfigResult['config_win'] != null && $getConfigResult['config_win'] != '') {
					$request = "SELECT * FROM configs WHERE name = '".mysqli_real_escape_string($database, $getConfigResult['config_win'])."'";
				} else {
					echo 'noconfig';
				}
            } else {
				if ($getConfigResult['config_linux'] != null && $getConfigResult['config_linux'] != '') {
					$request = "SELECT * FROM configs WHERE name = '".mysqli_real_escape_string($database, $getConfigResult['config_linux'])."'";
				} else {
					echo 'noconfig';
				}
            }
            $query = mysqli_query($database, $request);
            $result = mysqli_fetch_assoc($query);
            $groupfolders = json_decode($result['groupfolders']);
            $groupfolders = (object)$groupfolders;
            $groupfolders = json_encode($groupfolders);
            $data = array();
            array_push($data, array('dologin', $result['dologin']),
                       array('loginpending', $result['loginpending']),
                       array('loginfailed', $result['loginfailed']),
                       array('wrongcredentials', $result['wrongcredentials']),
                       array('networkfailed', $result['networkfailed']),
                       array('success', $result['success']),
                       array('shutdown', $result['shutdown']),
                       array('smbserver', $result['smbserver']),
                       array('driveone', $result['driveone']),
                       array('drivetwo', $result['drivetwo']),
                       array('drivethree', $result['drivethree']),
                       array('pathone', $result['pathone']),
                       array('pathtwo', $result['pathtwo']),
                       array('paththree', $result['paththree']),
                       array('infotext', $result['infotext']),
                       array('room', $getConfigResult['room']),
                       array('machinename', $getConfigResult['machine']),
                       array('groupfolders', $groupfolders));
            $data = (object)$data;
            echo json_encode($data);
        } elseif ($_POST['usage'] == 'internet') {
            //Internet für einzelnen Rechener / ganzen Raum sperren / freigeben
			if ($getConfigResult['teacher'] == '1') {
                if ($_POST['lock'] == '1') {
                    if ($_POST['task'] == 'room') {
                        $inetRequest = "UPDATE machines SET ipfire = 1 WHERE room = '".mysqli_real_escape_string($database, $getConfigResult['room'])."' AND teacher = 0 AND inet = 0";
                    } else {
                        $inetRequest = "UPDATE machines SET ipfire = 1 WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['target'])."' AND teacher = 0 AND inet = 0";
                    }
                } else {
                    if ($_POST['task'] == 'room') {
                        $inetRequest = "UPDATE machines SET ipfire = 0 WHERE room = '".mysqli_real_escape_string($database, $getConfigResult['room'])."' AND teacher = 0 AND inet = 0";
                    } else {
                        $inetRequest = "UPDATE machines SET ipfire = 0 WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['target'])."' AND teacher = 0 AND inet = 0";
                    }
                }
                $inetQuery = mysqli_query($database, $inetRequest);
                $request = "SELECT machine, ip, ipfire FROM machines";
				$query = mysqli_query($database, $request);
				$customhosts = fopen("customhosts", "w");
				$customgroups = fopen("customgroups", "w");
				$counter = 1;
				while ($result = mysqli_fetch_assoc($query)) {
					fwrite($customhosts, $counter.",".$result['machine'].",ip,".$result['ip']."/255.255.255.255\n");
					if ($result['ipfire'] == 0) {
						fwrite($customgroups, $counter.",blocked,,".$result['machine'].",Custom Host\n");
					}
					$counter++;
				}
				fclose($customhosts);
				fclose($customgroups);
                //Dateien per SCP auf IPFire kopieren und per SSH neu laden
				$connection = ssh2_connect(loadConfig('ipfire', 'url'), 22);
				ssh2_auth_pubkey_file($connection, loadConfig('ipfire', 'user'), loadConfig('ipfire', 'pubkey'), loadConfig('ipfire', 'rsafile'));
				ssh2_scp_send($connection, 'customhosts', '/var/ipfire/fwhosts/customhosts', 0644);
				ssh2_scp_send($connection, 'customgroups', '/var/ipfire/fwhosts/customgroups', 0644);
				ssh2_exec($connection, '/usr/local/bin/firewallctrl');
			} else {
                echo 'noaccess';
            }
        } elseif ($_POST['usage'] == 'roomlist') {
			//Liste aller Rechner eines Raumes für Lehrerclient
			if ($getConfigResult['teacher'] == '1') {
				$request = "SELECT room, machine, hardwareid, ip, ipfire FROM machines WHERE room = '".mysqli_real_escape_string($database, $getConfigResult['room'])."' AND teacher = '0'";
				$query = mysqli_query($database, $request);
				$data = array();
				while ($response = mysqli_fetch_assoc($query)) {
					$machineData = array($response['room'], $response['machine'], $response['ip'], $response['hardwareid'], $response['ipfire']);
					array_push($data, $machineData);
				}
				$data = (object)$data;
				echo json_encode($data);
			} else {
				echo 'noaccess';
			}
		} elseif ($_POST['usage'] == 'wake') {
			//Rechner per Wake on LAN einschalten
			if ($getConfigResult['teacher'] == '1') {
                shell_exec('wakeonlan '.$_GET['targetMac']);
            } else {
                echo 'noaccess';
            }
		} elseif ($_POST['usage'] == 'checkteacher') {
			$teacherRequest = "SELECT teacher FROM machines WHERE ip = '".mysqli_real_escape_string($database, $_POST['req'])."'";
			$teacherQuery = mysqli_query($database, $teacherRequest);
			$teacherResponse = mysqli_fetch_assoc($teacherQuery);
			if ($teacherResponse['teacher'] == '1') {
				echo 'success';
			} else {
				echo 'noaccess';
			}
		} elseif ($_POST['usage'] == 'checkinet') {
			$chkInetRequest = "SELECT ipfire FROM machines WHERE hardwareid = '".mysqli_real_escape_string($database, $_POST['hwaddr'])."'";
			$chkInetQuery = mysqli_query($database, $chkInetRequest);
			$chkInetResult = mysqli_fetch_assoc($chkInetQuery);
			echo $chkInetResult['ipfire'];
		}
    } else {
        echo '!';
    }
?>
