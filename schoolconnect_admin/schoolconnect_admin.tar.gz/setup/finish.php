<?php
    $config = unserialize(file_get_contents('../config.txt'));
    if ($config['config'] == 'done') {
        header('Location: ../ui/nologin.php');
    }
    if ($_POST['isReady'] == 'true') {
        include "../api/accessConfig.php";
        changeConfigValue('config', null, 'done');
        header('Location: ../ui/nologin.php');
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Setup - Fertigstellen - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../ui/ressources/css/styles.css">
    <link rel="stylesheet" href="../ui/ressources/css/swal.css" type="text/css">
    <script src="../ui/ressources/js/responsive-nav.min.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="../ui/ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <li>
                <a href="#">Willkommen</a>
            </li>
            <li>
                <a href="#">Datenbank</a>
            </li>
            <li>
                <a href="#">LDAP-Server</a>
            </li>
            <li>
                <a href="#">IPFire</a>
            </li>
            <li>
                <a href="#">Administratorkonto</a>
            </li>
            <li class="active">
                <a href="#">Fertigstellen</a>
            </li>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px;"><b>FERTIG</b>STELLEN</p>
        <p>PhilleConnect wurde erfolgreich konfiguriert. Mit 'Fertigstellen' wird die Konfiguration abgeschlossen.</p>
        <form action="finish.php" method="post">
            <input type="submit" value="Fertigstellen"/>
            <input type="hidden" value="true" name="isReady"/>
        </form>
    </div>
    <script src="../ui/ressources/js/jquery.js"></script>
    <script src="../ui/ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
    </script>
</body>
</html>