<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Setup - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../ui/ressources/css/styles.css">
    <link rel="stylesheet" href="../ui/ressources/css/swal.css" type="text/css">
    <script src="../ui/ressources/js/responsive-nav.min.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="../ui/ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <li class="active">
                <a href="#">Willkommen</a>
            </li>
            <li>
                <a href="#">Datenbank</a>
            </li>
            <li>
                <a href="#">LDAP-Server</a>
            </li>
            <li>
                <a href="#">IPFire</a>
            </li>
            <li>
                <a href="#">Administratorkonto</a>
            </li>
            <li>
                <a href="#">Fertigstellen</a>
            </li>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
    </div>
    <script src="../ui/ressources/js/jquery.js"></script>
    <script src="../ui/ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        <?php
            if (is_writeable('../config.txt')) {
                ?>
                var hasWritePermission = true;
                <?php
            } else {
                ?>
                var hasWritePermission = false;
                <?php
            }
        ?>
        if (hasWritePermission) {
            swal({
                title: 'Willkommen bei PhilleConnect!',
                text: 'Der Server ist eingerichtet und bereit für die Konfiguration. Fangen wir an!',
                confirmButtonText: '>> Weiter',
                type: 'info'
            }).then(function() {
                window.location.href = 'database.php';
            });
        } else {
            swal({
                title: 'Willkommen bei PhilleConnect!',
                text: 'PHP hat keine Schreibrechte auf die Datei config.txt. Bitte stelle sicher, dass PHP in diese Datei schreiben kann und lade diese Seite erneut!',
                type: 'warning',
                showConfirmButton: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
            });
        }
    </script>
</body>
</html>