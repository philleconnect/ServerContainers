<!DOCTYPE html>
<?php
    $page = "nologin";
    include "../api/dbconnect.php";
    include "menue.php";
?>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Login - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
    <script src="ressources/js/responsive-nav.min.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
    </div>
    <script src="ressources/js/jquery.js"></script>
    <script src="ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        function getAjaxRequest() {
            var ajax = null;
            ajax = new XMLHttpRequest;
            return ajax;
        }
        function showLoginModal() {
            swal({
                title: 'Bitte Nutzerdaten eingeben.',
                html: '<input type="text" id="swal-input1" placeholder="Nutzername" class="swal2-input"/><input type="password" id="swal-input2" placeholder="Passwort" class="swal2-input"/>',
                showCancelButton: false,
                confirmButtonText: 'Anmelden',
                showLoaderOnConfirm: true,
                allowOutsideClick: false,
                allowEscapeKey: false,
                preConfirm: function() {
                    return new Promise(function (resolve, reject) {
                        var url = '../api/checklogin.php';
                        var params = 'uname='+$('#swal-input1').val()+'&passwd='+$('#swal-input2').val();
                        ajax = getAjaxRequest();
                        ajax.onreadystatechange=stateChangedLogin;
                        ajax.open("POST",url,true);
                        ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                        ajax.setRequestHeader("Content-length", params.length);
                        ajax.setRequestHeader("Connection", "close");
                        ajax.send(params);
                        function stateChangedLogin() {
                            if (ajax.readyState == 4) {
                                if (ajax.responseText == 'success') {
                                    window.location.href = 'index.php';
                                } else if (ajax.responseText == 'wrongcredentials') {
                                    reject('Das Passwort ist falsch.')
                                } else {
                                    swal({
                                        title: 'Es ist ein Fehler aufgetreten.',
                                        showCancelButton: false,
                                        closeOnConfirm: false,
                                        type: 'error'
                                    }).then(function() {
                                        showLoginModal();
                                    });
                                }
                            }
                        }
                    })
                }
            });
        }
        showLoginModal();
    </script>
</body>
</html>