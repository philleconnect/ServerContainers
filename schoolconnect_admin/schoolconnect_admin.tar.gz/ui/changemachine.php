<!DOCTYPE html>
<?php
    $page = 'Rechnerverwaltung';
    include "../api/dbconnect.php";
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        header("Location: nologin.php");
    } elseif ($_SESSION['type'] != '1' && $_SESSION['type'] != '3') {
        header("Location: restricted.php");
    } else {
        include "menue.php";
    }
?>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Rechner bearbeiten - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
    <script src="ressources/js/responsive-nav.min.js"></script>
    <script src="ressources/js/sort.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px; text-transform: uppercase;"><b>RECHNER</b>BEARBEITEN</p>
        <p><b>Achtung:</b> Bei Änderung des Raums auf korrekte Schreibweise achten! Es wird zwischen Groß- und Kleinschreibung unterschieden!</p>
        <?php
            $request = "SELECT room, machine, config_win, config_linux, teacher, inet FROM machines WHERE id = ".$_GET['id'];
            $query = mysqli_query($database, $request);
            $response = mysqli_fetch_assoc($query);
        ?>
        <table>
            <tr>
                <td>Rechnername:</td>
                <td><input type="text" id="name" value="<?php echo $response['machine']; ?>"/></td>
            </tr>
            <tr>
                <td>Raum:</td>
                <td><input type="text" id="room" value="<?php echo $response['room']; ?>"/></td>
            </tr>
            <tr>
                <td>Konfigurationsprofil Windows:</td>
                <td>
                    <select id="config-win">
                        <?php
                            $request = "SELECT name FROM configs WHERE os = 'win'";
                            $query = mysqli_query($database, $request);
                            while ($result = mysqli_fetch_assoc($query)) {
                                if ($result['name'] == $response['config_win']) {
                                    echo '<option value="'.$result['name'].'" selected>'.$result['name'].'</option>';
                                } else {
                                    echo '<option value="'.$result['name'].'">'.$result['name'].'</option>';
                                }
                            }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Konfigurationsprofil Linux:</td>
                <td>
                    <select id="config-linux">
                        <?php
                            $request = "SELECT name FROM configs WHERE os = 'linux'";
                            $query = mysqli_query($database, $request);
                            while ($result = mysqli_fetch_assoc($query)) {
                                if ($result['name'] == $response['config_linux']) {
                                    echo '<option value="'.$result['name'].'" selected>'.$result['name'].'</option>';
                                } else {
                                    echo '<option value="'.$result['name'].'">'.$result['name'].'</option>';
                                }
                            }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Lehrer-PC</td>
                <td><input type="checkbox" id="teacherpc"/></td>
            </tr>
            <tr>
                <td>Internet bei Boot</td>
                <td><input type="checkbox" id="inet"/></td>
            </tr>
            <tr>
                <td>Aktion:</td>
                <td><button onclick="goBack()">Abbrechen</button></td>
            </tr>
            <tr>
                <td></td>
                <td><button onclick="saveMachine()">Speichern</button></td>
            </tr>
        </table>
    </div>
    <script src="ressources/js/jquery.js"></script>
    <script src="ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        <?php
            if ($response['teacher'] == '1') {
                echo "document.getElementById('teacherpc').checked = true;";
            } else {
                echo "document.getElementById('teacherpc').checked = false;";
            }
            if ($response['inet'] == '1') {
                echo "document.getElementById('inet').checked = true;";
            } else {
                echo "document.getElementById('inet').checked = false;";
            }
            include "link.php";
        ?>
        function goBack() {
            window.location.href = 'machines.php';
        }
        function getAjaxRequest() {
            var ajax = null;
            ajax = new XMLHttpRequest;
            return ajax;
        }
        function saveMachine() {
            if (document.getElementById('teacherpc').checked == true) {
                var teacherpc = '1';
            } else {
                var teacherpc = '0';
            }
            if (document.getElementById('inet').checked == true) {
                var inet = '1';
            } else {
                var inet = '0';
            }
            request = getAjaxRequest();
            var url = "../api/savemachine.php";
            var params = "room="+document.getElementById("room").value+"&machine="+document.getElementById("name").value+"&config_win="+document.getElementById("config-win").value+"&config_linux="+document.getElementById("config-linux").value+"&id=<?php echo $_GET['id'] ?>&inet="+inet+"&teacherpc="+teacherpc;
            request.onreadystatechange=stateChangedSave;
            request.open("POST",url,true);
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            request.setRequestHeader("Content-length", params.length);
            request.setRequestHeader("Connection", "close");
            request.send(params);
            function stateChangedSave() {
                if (request.readyState == 4) {
                    if (request.responseText == "success") {
                        swal({
                            title: "Änderungen erfolgreich gespeichert!",
                            type: "success",
                        }).then(function() {
                            window.location.href = 'machines.php';
                        })
                    } else {
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen.",
                            type: "error",
                        })
                    }
                }
            }
        }
    </script>
</body>
</html>