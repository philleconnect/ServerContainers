<!DOCTYPE html>
<?php
    $page = "Konfigurationsprofile";
    include "../api/dbconnect.php";
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        header("Location: nologin.php");
    } elseif ($_SESSION['type'] != '1' && $_SESSION['type'] != '3') {
        header("Location: restricted.php");
    } else {
        include "menue.php";
    }
?>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Konfigurationsprofil bearbeiten - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
    <script src="ressources/js/responsive-nav.min.js"></script>
    <script src="ressources/js/sort.js"></script>
    <meta name="robots" content="noindex">
    <style>
        table {
            width: 100%;
        }
    </style>
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px;"><b>KONFIGURATIONSPROFIL</b>BEARBEITEN</p>
        <br />
        <?php
            $request = "SELECT * FROM configs WHERE id = ".mysqli_real_escape_string($database, $_GET['id']);
            $query = mysqli_query($database, $request);
            $response = mysqli_fetch_assoc($query);
        ?>
        <div class="datagrid">
            <table>
                <thead>
                    <tr>
                        <th>Einstellung:</th>
                        <th>Parameter:</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Name:</td>
                        <td>
                            <?php
                                if ($_GET['mode'] == 'new') {
                                    ?>
                                    <input type="text" id="name" value="<?php echo $response['name']; ?>"/>
                                    <?php
                                } else {
                                    ?>
                                    <input type="text" readonly id="name" value="<?php echo $response['name']; ?>"/>
                                    <?php
                                }
                            ?>
                        </td>
                    </tr>
                    <tr class="alt">
                        <td>SMB Server URL:</td>
                        <td><input type="text" id="smb" value="<?php echo $response['smbserver']; ?>"/></td>
                    </tr>
                    <tr>
                        <td>Betriebssystem:</td>
                        <td>
                            <?php
                                if ($_GET['mode'] == 'new') {
                                    if ($response['os'] == 'win') {
                                        ?>
                                        <input type="radio" name="os" id="linux"/> Linux
                                        <br />
                                        <input type="radio" name="os" id="win" checked/> Windows
                                        <?php
                                    } else {
                                        ?>
                                        <input type="radio" name="os" id="linux" checked/> Linux
                                        <br />
                                        <input type="radio" name="os" id="win"/> Windows
                                        <?php
                                    }
                                } else {
                                    echo $response['os'];
                                    ?>
                                    <input type="hidden" id="os" value="<?php echo $response['os']; ?>"/>
                                    <?php
                                }
                            ?>
                        </td>
                    </tr>
                    <tr class="alt">
                        <td>Herunterfahren nach ... Sekunden:</td>
                        <td><input type="text" id="shutdown" onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?php echo $response['shutdown']; ?>"/></td>
                    </tr>
                    <tr>
                        <td>Gruppenlaufwerke:</td>
                        <td>
                            <table id="group-table">
                                
                            </table>
                        </td>
                    </tr>
                    <tr class="alt">
                        <td>Userlaufwerke:</td>
                        <td>
                            <table>
                                <tr>
                                    <td>Laufwerk 1:</td>
                                    <td><input type="text" id="driveone" value="<?php echo $response['driveone']; ?>"/></td>
                                    <td><input type="text" id="pathone" value="<?php echo $response['pathone']; ?>"/></td>
                                </tr>
                                <tr>
                                    <td>Laufwerk 2:</td>
                                    <td><input type="text" id="drivetwo" value="<?php echo $response['drivetwo']; ?>"/></td>
                                    <td><input type="text" id="pathtwo" value="<?php echo $response['pathtwo']; ?>"/></td>
                                </tr>
                                <tr>
                                    <td>Laufwerk 3:</td>
                                    <td><input type="text" id="drivethree" value="<?php echo $response['drivethree']; ?>"/></td>
                                    <td><input type="text" id="paththree" value="<?php echo $response['paththree']; ?>"/></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td>Infotexte:</td>
                        <td>
                            <table>
                                <tr>
                                    <td>Bitte anmelden:</td>
                                    <td><textarea class="infotext" id="dologin"><?php echo $response['dologin']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Anmeldung läuft:</td>
                                    <td><textarea class="infotext" id="loginpending"><?php echo $response['loginpending']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Anmeldung fehlgeschlagen:</td>
                                    <td><textarea class="infotext" id="loginfailed"><?php echo $response['loginfailed']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Zugangsdaten falsch:</td>
                                    <td><textarea class="infotext" id="wrongcredentials"><?php echo $response['wrongcredentials']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Netzwerkfehler:</td>
                                    <td><textarea class="infotext" id="networkfailed"><?php echo $response['networkfailed']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Anmeldung erfolgreich:</td>
                                    <td><textarea class="infotext" id="success"><?php echo $response['success']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Hinweisfenster:</td>
                                    <td><textarea class="infotext" id="infotext"><?php echo $response['infotext']; ?></textarea></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr class="alt">
                        <td>Servicemode:</td>
                        <td><input type="checkbox" id="servicemode"/></td>
                    </tr>
                    <tr>
                        <td>Aktion:</td>
                        <td><button onclick="goBack()">Abbrechen</button></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><button onclick="saveConfig()">Speichern</button></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><button onclick="deleteConfig()">Löschen</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <script src="ressources/js/jquery.js"></script>
    <script src="ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        var groupfolders = JSON.parse('<?php echo $response['groupfolders']; ?>');
        writeGroupFolders();
        <?php if ($response['servicemode'] == '1') { ?>
		document.getElementById('servicemode').checked = true;
		<?php } ?>
        function writeGroupFolders() {
            var c = 0;
            document.getElementById("group-table").innerHTML = '';
            while (groupfolders[c] != null) {
                document.getElementById("group-table").innerHTML += '<tr><td>'+groupfolders[c][0]+' | '+groupfolders[c][1]+' | <a href="#" onclick="changeGroupFolder('+c+', \''+groupfolders[c][0]+'\', \''+groupfolders[c][1]+'\')">Bearbeiten</a> | <a href="#" onclick="deleteGroupFolder('+c+')">Löschen</a></td></tr>';
                c++;
            }
            document.getElementById("group-table").innerHTML += '<tr><td><button onclick="addGroupFolder()">Laufwerk hinzufügen</button></td></tr>';
        }
        function changeGroupFolder(id, a, b) {
            swal({
                title: 'Gruppenlaufwerk bearbeiten',
                html: 'Pfad am Rechner: <input type="text" id="machinepath" value="'+a+'"/><br />Pfad auf dem Server: <input type="text" id="smbpath" value="'+b+'"/>',
            }).then(function() {
                swal.disableButtons();
                groupfolders[id][0] = document.getElementById("machinepath").value;
                groupfolders[id][1] = document.getElementById("smbpath").value;
                writeGroupFolders();
            })
        }
        function deleteGroupFolder(id) {
            groupfolders.splice(id, (id+1));
            writeGroupFolders();
        }
        function addGroupFolder() {
            swal({
                title: 'Gruppenlaufwerk hinzufügen',
                html: 'Pfad am Rechner: <input type="text" id="machinepath" placeholder="Mountpunkt"/><br />Pfad auf dem Server: <input type="text" id="smbpath" placeholder="Serverpfad"/>',
                closeOnConfirm: false,
            }).then(function() {
                swal.disableButtons();
                if (document.getElementById("machinepath").value == '' || document.getElementById("smbpath").value == '') {
                    swal({
                        title: 'Bitte alle Felder ausfüllen.',
                        text: 'Laufwerk nicht hinzugrfügt.',        
                        type: 'warning',
                    })
                } else {
                    var newfolder = [document.getElementById("machinepath").value, document.getElementById("smbpath").value];
                    groupfolders.push(newfolder);
                    writeGroupFolders();
                    swal({title:"", timer:1});
                }
            })
        }
        function goBack() {
            window.location.href = 'config.php';
        }
        function getAjaxRequest() {
            var ajax = null;
            ajax = new XMLHttpRequest;
            return ajax;
        }
        function saveConfig() {
            <?php
                if ($_GET['mode'] == 'new') {
                    ?>
            if (document.getElementById("linux").checked) {
                var os = 'linux';
            } else {
                var os = 'win';
            }
                    <?php
                } else {
                    ?>
            var os = document.getElementById('os').value;
                    <?php
                }
            ?>
            var mode = '<?php echo $_GET['mode']; ?>';
            request = getAjaxRequest();
            var url = "../api/saveconfig.php";
            if (document.getElementById('servicemode').checked) {
				var servicemode = '1';
			} else {
				var servicemode = '0';
			}
            var params = "name="+document.getElementById("name").value+"&os="+os+"&smbserver="+document.getElementById("smb").value+"&driveone="+document.getElementById("driveone").value+"&drivetwo="+document.getElementById("drivetwo").value+"&drivethree="+document.getElementById("drivethree").value+"&pathone="+document.getElementById("pathone").value+"&pathtwo="+document.getElementById("pathtwo").value+"&paththree="+document.getElementById("paththree").value+"&shutdown="+document.getElementById("shutdown").value+"&dologin="+document.getElementById("dologin").value+"&loginpending="+document.getElementById("loginpending").value+"&loginfailed="+document.getElementById("loginfailed").value+"&wrongcredentials="+document.getElementById("wrongcredentials").value+"&networkfailed="+document.getElementById("networkfailed").value+"&success="+document.getElementById("success").value+"&groupfolders="+JSON.stringify(groupfolders)+"&infotext="+document.getElementById("infotext").value+"&mode="+mode+"&id=<?php echo $_GET['id'] ?>&servicemode="+servicemode;
            request.onreadystatechange=stateChangedSave;
            request.open("POST",url,true);
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            request.setRequestHeader("Content-length", params.length);
            request.setRequestHeader("Connection", "close");
            request.send(params);
            function stateChangedSave() {
                if (request.readyState == 4) {
                    if (request.responseText == "success") {
                        swal({
                            title: "Änderungen erfolgreich gespeichert!",
                            type: "success",
                        }).then(function() {
                            swal.disableButtons();
                            window.location.href = 'config.php';
                        })
                    } else if (request.responseText == "naming") {
                        swal({
                            title: "Es existiert bereits ein Konfigurationsprofil mit diesem Namen.",
                            text: "Bitte wähle einen anderen Namen und erneut versuchen.",
                            type: "error",
                        })
                    } else {
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen.",
                            type: "error",
                        })
                    }
                }
            }
        }
        function deleteConfig() {
            swal({
                title: 'Konfigurationsprofil löschen?',
                text: 'Das Konfigurationsprofil wird für immer verschwunden sein (eine lange Zeit)!',
                type: 'question',
                showCancelButton: true,
                confirmButtonText: 'Löschen',
                cancelButtonText: 'Abbrechen',
                confirmButtonColor: '#D33',
                cancelButtonColor: "#3085d6",
                preConfirm: function() {
                    return new Promise(function(resolve) {
                        request = getAjaxRequest();
                        var url = "../api/saveconfig.php";
                        var params = "name="+document.getElementById("name").value+"&os="+document.getElementById("os").value+"&mode=delete&id=<?php echo $_GET['id'] ?>";
                        request.onreadystatechange=stateChangedSave;
                        request.open("POST",url,true);
                        request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                        request.setRequestHeader("Content-length", params.length);
                        request.setRequestHeader("Connection", "close");
                        request.send(params);
                        function stateChangedSave() {
                            if (request.readyState == 4) {
                                if (request.responseText == "success") {
                                    resolve();
                                } else if (request.responseText == "inuse") {
                                    swal({
                                        title: "Profil in Verwendung.",
                                        text: "Dieses Konfigurationsprofil ist derzeit in Verwendung. Bitte weisen Sie zuerst allen Rechnern, die dieses Profil verwenden, ein anderes Profil zu.",
                                        type: "warning",
                                    })
                                } else {
                                    swal({
                                        title: "Es ist ein Fehler aufgetreten.",
                                        text: "Bitte erneut versuchen.",
                                        type: "error",
                                    })
                                }
                            }
                        }
                    })
                },
            }).then(function() {
                swal({
                    title: "Konfigurationsprofil erfolgreich gelöscht!",
                    type: "success",
                }).then(function() {
                    window.location.href = 'config.php';
                })
            })
        }
    </script>
</body>
</html>
