<!DOCTYPE html>
<?php
    $page = "Grundkonfiguration";
    include "../api/dbconnect.php";
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        header("Location: nologin.php");
    } elseif ($_SESSION['type'] != '1') {
        header("Location: restricted.php");
    } else {
        include "menue.php";
        include "../api/accessConfig.php";
    }
?>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Grundkonfiguration - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
    <script src="ressources/js/responsive-nav.min.js"></script>
    <script src="ressources/js/sort.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px;"><b>GRUND</b>KONFIGURATION</p>
        <br />
        <p>Einstellung globaler Konfigurationsparameter</p>
        <br />
        <p><b>Warnung:</b> Änderungen am globalen Passwort können die gesamte Installation blockieren.</p>
        <br />
        <div class="datagrid">
            <table>
                <thead>
                    <tr>
                        <th style="width: 50%;">LDAP-Server</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>URL:</td>
                        <td><input type="url" value="<?php echo loadConfig('ldap', 'url'); ?>" id="ldap_url" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>LDAP Admin-Passwort:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'password'); ?>" id="ldap_password" size="40"/></td>
                    </tr>
                    <tr>
                        <td>Basis-DN:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'basedn'); ?>" id="ldap_basedn" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>DN des Admin-Users:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'admindn'); ?>" id="ldap_admindn" size="40"/></td>
                    </tr>
                    <tr>
                        <td>DN der Useraccounts:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'usersdn'); ?>" id="ldap_usersdn" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>DN der Gruppen:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'groupsdn'); ?>" id="ldap_groupsdn" size="40"/></td>
                    </tr>
                    <tr>
                        <td>CN der Schülergruppe:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'studentscn'); ?>" id="ldap_studentscn" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>CN der Lehrergruppe:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'teacherscn'); ?>" id="ldap_teacherscn" size="40"/></td>
                    </tr>
                    <tr>
                        <td>Samba-Hostname:</td>
                        <td><input type="text" value="<?php echo loadConfig('ldap', 'sambahostname'); ?>" id="ldap_sambahostname" size="40"/></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <button onclick="saveObject('LDAP-Server Einstellungen', 'ldap')">LDAP-Einstellungen speichern</button>
        <div class="datagrid">
            <table>
                <thead>
                    <tr>
                        <th style="width: 50%;">IPFire</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>URL:</td>
                        <td><input type="url" value="<?php echo loadConfig('ipfire', 'url'); ?>" id="ipfire_url" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>Benutzer:</td>
                        <td><input type="text" value="<?php echo loadConfig('ipfire', 'user'); ?>" id="ipfire_user" size="40"/></td>
                    </tr>
                    <tr>
                        <td>Public Key file:</td>
                        <td><input type="text" value="<?php echo loadConfig('ipfire', 'pubkey'); ?>" id="ipfire_pubkey" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>RSA file:</td>
                        <td><input type="text" value="<?php echo loadConfig('ipfire', 'rsafile'); ?>" id="ipfire_rsafile" size="40"/></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <button onclick="saveObject('IPFire Einstellungen', 'ipfire')">IPFire-Einstellungen speichern</button>
        <div class="datagrid">
            <table>
                <thead>
                    <tr>
                        <th style="width: 50%;">Installation</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Globales Passwort:</td>
                        <td><input type="text" value="<?php echo loadConfig('globalPw', null); ?>" id="globalPw" size="40"/></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <button onclick="saveObject('Installationseinstellungen', 'globalPw')">Installationseinstellungen speichern</button>
        <div class="datagrid">
            <table>
                <thead>
                    <tr>
                        <th style="width: 50%;">Mein Passwort ändern</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Neues Passwort:</td>
                        <td><input type="password" id="my_pwd" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>Neues Passwort bestätigen:</td>
                        <td><input type="password" id="my_pwd2" size="40"/></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <button onclick="changePassword()">Passwort ändern</button>
        <div class="datagrid">
            <table>
                <thead>
                    <tr>
                        <th style="width: 50%;">Admin-Account hinzufügen</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Nutzername:</td>
                        <td><input type="text" id="new_user" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>Berechtigungsstufe:</td>
                        <td>
                            <select id="new_rights">
                                <option value="1">Administrator</option>
                                <option value="2">Accountverwalter</option>
                                <option value="3">Rechnerverwalter</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Passwort:</td>
                        <td><input type="password" id="new_pwd" size="40"/></td>
                    </tr>
                    <tr class="alt">
                        <td>Passwort bestätigen:</td>
                        <td><input type="password" id="new_pwd2" size="40"/></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <button onclick="addAdmin()">Admin-Account hinzufügen</button>
    </div>
    <script src="ressources/js/jquery.js"></script>
    <script src="ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        function saveObject(title, prefix) {
            swal({
                title: title+' speichern?',
                showCancelButton: true,
                cancelButtonText: 'Abbrechen',
                confirmButtonText: 'Speichern',
                closeOnConfirm: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                type: 'question'
            }).then(function() {
                swal.disableButtons();
                setParameter(prefix);
            });
        }
        function getAjaxRequest() {
            var ajax = null;
            ajax = new XMLHttpRequest;
            return ajax;
        }
        function setParameter(prefix) {
            request = getAjaxRequest();
            var url = "../api/saveglobal.php";
            if (prefix == 'ldap') {
                var value = "&url="+document.getElementById('ldap_url').value+"&password="+document.getElementById('ldap_password').value+"&basedn="+document.getElementById('ldap_basedn').value+"&admindn="+document.getElementById('ldap_admindn').value+"&usersdn="+document.getElementById('ldap_usersdn').value+"&groupsdn="+document.getElementById('ldap_groupsdn').value+"&studentscn="+document.getElementById('ldap_studentscn').value+"&teacherscn="+document.getElementById('ldap_teacherscn').value+"&sambahostname="+document.getElementById('ldap_sambahostname').value;
            } else if (prefix == 'ipfire') {
                var value = "&url="+document.getElementById('ipfire_url').value+"&user="+document.getElementById('ipfire_user').value+"&pubkey="+document.getElementById('ipfire_pubkey').value+"&rsafile="+document.getElementById('ipfire_rsafile').value;
            } else if (prefix == 'globalPw') {
                var value = "&globalPw="+document.getElementById('globalPw').value;
            }
            var params = "prefix="+prefix+value;
            request.onreadystatechange=stateChangedSave;
            request.open("POST",url,true);
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            request.setRequestHeader("Content-length", params.length);
            request.setRequestHeader("Connection", "close");
            request.send(params);
            function stateChangedSave() {
                if (request.readyState == 4) {
                    if (request.responseText == "success") {
                        swal({
                            title: "Änderungen erfolgreich gespeichert!",
                            type: "success",
                        }).then(function() {
                            window.location.reload();
                        })
                    } else if (request.responseText == "denied") {
                        swal({
                            title: "Zugriffsfehler.",
                            text: "Du besitzt nicht die nötigen Rechte für diese Aktion.",
                            type: "warning",
                        }) 
                    } else {
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen.",
                            type: "error",
                        })
                    }
                }
            }
        }
        function changePassword() {
            swal({
                title: 'Passwort ändern?',
                showCancelButton: true,
                cancelButtonText: 'Abbrechen',
                confirmButtonText: 'Ändern',
                closeOnConfirm: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                type: 'question'
            }).then(function() {
                swal.disableButtons();
                request = getAjaxRequest();
                var url = "../api/changeadminpassword.php";
                var params = "pwd="+document.getElementById('new_pwd').value+"&pwd2"+document.getElementById('new_pwd2').value;
                request.onreadystatechange=stateChangedSave;
                request.open("POST",url,true);
                request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                request.setRequestHeader("Content-length", params.length);
                request.setRequestHeader("Connection", "close");
                request.send(params);
                function stateChangedSave() {
                    if (request.readyState == 4) {
                        if (request.responseText == "success") {
                            swal({
                                title: "Passwort erfolgreich geändert!",
                                type: "success",
                            }).then(function() {
                                window.location.reload();
                            });
                        } else if (request.responseText == "denied") {
                            swal({
                                title: "Zugriffsfehler.",
                                text: "Du besitzt nicht die nötigen Rechte für diese Aktion.",
                                type: "warning",
                            })  
                        } else if (request.responseText == "notsame") {
                            swal({
                                title: "Die Passwörter stimmen nicht überein.",
                                text: "Bitte eingaben überprüfen.",
                                type: "warning",
                            })
                        } else if (request.responseText == "database_error") {
                            swal({
                                title: "Es ist ein Datenbankfehler aufgetreten.",
                                text: "Bitte erneut versuchen.",
                                type: "error",
                            })
                        } else {
                            swal({
                                title: "Es ist ein Fehler aufgetreten.",
                                text: "Bitte erneut versuchen.",
                                type: "error",
                            })
                        }
                    }
                }
            });
        }
        function addAdmin() {
            swal({
                title: 'Admin hinzufügen?',
                showCancelButton: true,
                cancelButtonText: 'Abbrechen',
                confirmButtonText: 'Ändern',
                closeOnConfirm: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                type: 'question'
            }).then(function() {
                request = getAjaxRequest();
                var url = "../api/addadmin.php";
                var params = "username="+document.getElementById('new_user').value+"&pwd="+document.getElementById('new_pwd').value+"&pwd2"+document.getElementById('new_pwd2').value+"&type="+document.getElementById('new_rights').value;
                request.onreadystatechange=stateChangedSave;
                request.open("POST",url,true);
                request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                request.setRequestHeader("Content-length", params.length);
                request.setRequestHeader("Connection", "close");
                request.send(params);
                function stateChangedSave() {
                    if (request.readyState == 4) {
                        if (request.responseText == "success") {
                            swal({
                                title: "Admin erfolgreich hinzugefügt!",
                                type: "success",
                            }).then(function() {
                                window.location.reload();
                            });
                        } else if (request.responseText == "denied") {
                            swal({
                                title: "Zugriffsfehler.",
                                text: "Du besitzt nicht die nötigen Rechte für diese Aktion.",
                                type: "warning",
                            })  
                        } else if (request.responseText == "notsame") {
                            swal({
                                title: "Die Passwörter stimmen nicht überein.",
                                text: "Bitte eingaben überprüfen.",
                                type: "warning",
                            })
                        } else if (request.responseText == "database_error") {
                            swal({
                                title: "Es ist ein Datenbankfehler aufgetreten.",
                                text: "Bitte erneut versuchen.",
                                type: "error",
                            })
                        } else {
                            swal({
                                title: "Es ist ein Fehler aufgetreten.",
                                text: "Bitte erneut versuchen.",
                                type: "error",
                            })
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>
