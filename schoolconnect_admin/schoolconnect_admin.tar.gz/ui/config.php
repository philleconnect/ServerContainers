<!DOCTYPE html>
<?php
    $page = "Konfigurationsprofile";
    include "../api/dbconnect.php";
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        header("Location: nologin.php");
    } elseif ($_SESSION['type'] != '1' && $_SESSION['type'] != '3') {
        header("Location: restricted.php");
    } else {
        include "menue.php";
    }
?>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Konfigurationsprofile - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
    <script src="ressources/js/responsive-nav.min.js"></script>
    <script src="ressources/js/sort.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px;"><b>KONFIGURATIONS</b>PROFILE</p>
        <br />
        <p>Hier lassen sich für verschiedene Rechnertypen verschiedene Konfigurationsprofile anlegen. Jedem Rechner wird eine Konfiguration pro Betriebssystem zugewiesen.</p>
        <br />
        <table>
            <tr>
                <td>Konfigurationsprofil anlegen:</td>
                <td>
                    <select id="fill">
                        <option value="0">Keine Vorlage</option>
                        <?php
                            $request = "SELECT * FROM configs";
                            $query = mysqli_query($database, $request);
                            while ($result = mysqli_fetch_assoc($query)) {
                                echo '<option value="'.$result['id'].'">'.$result['name'].'</option>';
                            }
                        ?>
                    </select>
                </td>
                <td><button onclick="newConfig()">Anlegen</button></td>
            </tr>
        </table>
        <br />
        <p>Derzeit vorhandene Konfigurationsprofile:</p>
        <div class="datagrid" style="overflow: auto;">
            <table id="configs">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>OS</th>
                        <th>Samba-URL</th>
                        <th>Laufwerke</th>
                        <th>Gruppenlaufwerke</th>
                        <th>Herunterfahren nach</th>
                        <th>Infotexte</th>
                        <th>Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $request = "SELECT * FROM configs";
                        $query = mysqli_query($database, $request);
                        $i = 0;
                        while ($result = mysqli_fetch_assoc($query)) {
                            if ($i == 0) {
                                echo '<tr>';
                                $i = 1;
                            } else {
                                echo '<tr class="alt">';
                                $i = 0;
                            }
                            $drives = $result['driveone'].' ('.$result['pathone'].'); '.$result['drivetwo'].' ('.$result['pathtwo'].'); '.$result['drivethree'].' ('.$result['paththree'].')';
                            $decodedData = json_decode($result['groupfolders']);
                            $c = 0;
                            $groupFolders = "";
                            while ($decodedData[$c] != null) {
                                $groupFolders = $groupFolders.''.$decodedData[$c][0].' | '.$decodedData[$c][1].'<br />';
                                $c++;
                            }
                            $infos = '<b>Bitte anmelden:</b> '.$result['dologin'].'<br /><b>Login läuft:</b> '.$result['loginpending'].'<br /><b>Login fehlgeschlagen:</b> '.$result['loginfailed'].'<br /><b>Nutzerdaten falsch:</b> '.$result['wrongcredentials'].'<br /><b>Netzwerkfehler:</b> '.$result['networkfailed'].'<br /><b>Erfolg:</b> '.$result['success'].'<br /><b>Hinweisfenster (% = Absatz):</b><br /> '.$result['infotext'].'<br />';
                            echo '<td>'.$result["name"].'</td><td>'.$result["os"].'</td><td>'.$result["smbserver"].'</td><td>'.$drives.'</td><td><a href="#" onclick="showGroupFolders(\''.$result["name"].'\', \''.$groupFolders.'\')">Zeigen</a></td><td>'.$result["shutdown"].'</td><td><a href="#" onclick="showInfos(\''.$result["name"].'\', \''.$infos.'\')">Zeigen</a></td><td><a href="#" onclick="changeConfig('.$result["id"].')">Bearbeiten</a></td>';
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="ressources/js/jquery.js"></script>
    <script src="ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        var table_Props = {
            col_1: "select",
            col_2: "select",
            col_4: "none",
            col_5: "select",
            col_6: "none",
            col_7: "none",
            display_all_text: "Alle anzeigen",
            sort_select: true
        };
        var tf2 = setFilterGrid("configs", table_Props);
        function newConfig() {
            window.location.href = "changeconfig.php?mode=new&id="+document.getElementById("fill").value;
        }
        function changeConfig(id) {
            window.location.href = "changeconfig.php?mode=change&id="+id;
        }
        function showGroupFolders(name, content) {
            swal({
                title: 'Gruppenlaufwerke von ' + name,
                html: content,
            })
        }
        function showInfos(name, content) {
            swal({
                title: 'Infotexte von ' + name,
                html: content,
            })
        }
    </script>
</body>
</html>