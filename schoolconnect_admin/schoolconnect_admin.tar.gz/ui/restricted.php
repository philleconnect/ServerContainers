<!DOCTYPE html>
<?php
    $page = "nologin";
    include "../api/dbconnect.php";
    include "menue.php";
?>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Nicht berechtigt - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
    <script src="ressources/js/responsive-nav.min.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
    </div>
    <script src="ressources/js/jquery.js"></script>
    <script src="ressources/js/swal.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        function showLoginModal() {
            swal({
                title: 'Du hast keine Berechtigung für diesen Bereich.',
                showCancelButton: false,
                confirmButtonText: 'OK',
                closeOnConfirm: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                type: 'error'
            }).then(function() {
                window.location.href = 'index.php';
            });
        }
        showLoginModal();
    </script>
</body>
</html>