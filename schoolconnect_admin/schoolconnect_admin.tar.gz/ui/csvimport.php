<!DOCTYPE html>
<?php
    $page = 'CSV importieren';
    include "../api/dbconnect.php";
    session_start();
    if ($_SESSION['user'] == null || $_SESSION['user'] == '') {
        header("Location: nologin.php");
    } elseif ($_SESSION['type'] != '1' && $_SESSION['type'] != '2') {
        header("Location: restricted.php");
    } else {
        include "menue.php";
    }
?>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>CSV Import - PhilleConnect Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="stylesheet" href="ressources/css/swal.css" type="text/css">
    <script src="ressources/js/responsive-nav.min.js"></script>
    <meta name="robots" content="noindex">
</head>
<body>
    <div role="navigation" id="foo" class="nav-collapse">
        <div class="top">
            <img src="ressources/img/logo.png">
            <li><b>PHILLE</b>CONNECT</li>
        </div>
        <ul>
            <?php
                echo $menu;
            ?>
        </ul>
    </div>
    <div role="main" class="main">
        <a href="#nav" class="nav-toggle">Menu</a>
        <noscript>
            <p>Dein Browser unterstützt kein JavaScript oder JavaScript ist ausgeschaltet. Du musst JavaScript aktivieren, um diese Seite zu verwenden!</p>
        </noscript>
        <p style="font-family: Arial, sans-serif; font-size: 45px; text-transform: uppercase;"><b>CSV</b>IMPORT</p>
        <p>So funktioniert der universelle CSV Import:<br />
        1: Inhalt der CSV Datei in die Textbox kopieren.<br />
        2: CSV Datei konfigurieren. Dazu das verwendete Trennzeichen angeben und die Spaltennummern (1-X) der Daten angeben. Für nicht vorhandene Daten '-' eingeben.<br />
        3: Einträge importieren. <b>Erst importieren, wenn die Vorschau korrekt ist!</b></p>
        <table>
            <tr>
                <td><textarea id="csv" cols="50" rows="18" placeholder="Hier CSV-Text einfügen." oninput="loadCsv()"></textarea></td>
                <td>
                    <table>
                        <tr>
                            <td>CSV Konfigurieren:</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Trennzeichen:</td>
                            <td><input type="text" value="," id="spacer" size="10" oninput="doCsvPrecalc()"/></td>
                        </tr>
                        <tr>
                            <td>Vorname:</td>
                            <td><input type="text" value="-" id="givenname" size="10" oninput="doCsvPrecalc()"/></td>
                        </tr>
                        <tr>
                            <td>Name:</td>
                            <td><input type="text" value="-" id="sn" size="10" oninput="doCsvPrecalc()"/></td>
                        </tr>
                        <tr>
                            <td>E-Mail:</td>
                            <td><input type="text" value="-" id="mail" size="10" oninput="doCsvPrecalc()"/></td>
                        </tr>
                        <tr>
                            <td>Klasse:</td>
                            <td><input type="text" value="-" id="class" size="10" oninput="doCsvPrecalc()"/></td>
                        </tr>
                        <tr>
                            <td>Passwort:</td>
                            <td><input type="checkbox" id="password-checkbox" onclick="doCsvPrecalc()" checked/>&nbsp;<p>Geburtsdatum als Passwort verwenden</p></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="text" value="-" id="password" size="10" oninput="doCsvPrecalc()" disabled/></td>
                        </tr>
                        <tr>
                            <td>Geburtsdatum:</td>
                            <td>
                                <input type="text" value="-" id="gebdat" size="10" oninput="doCsvPrecalc()"/>
                                &nbsp;|&nbsp;
                                <select id="one" oninput="doCsvPrecalc()">
                                    <option value="1" selected>DD</option>
                                    <option value="2">MM</option>
                                    <option value="3">YYYY</option>
                                </select>
                                <input type="text" value="." id="dspacer-1" size="2"/>
                                <select id="two" oninput="doCsvPrecalc()">
                                    <option value="1">DD</option>
                                    <option value="2" selected>MM</option>
                                    <option value="3">YYYY</option>
                                </select>
                                <input type="text" value="." id="dspacer-2" size="2"/>
                                <select id="three" oninput="doCsvPrecalc()">
                                    <option value="1">DD</option>
                                    <option value="2">MM</option>
                                    <option value="3" selected>YYYY</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Gruppe:</td>
                            <td><input type="radio" name="group" value="teachers" id="teachers" onclick="doCsvPrecalc()"/> Lehrer<br /><input type="radio" name="group" value="students" id="students" onclick="doCsvPrecalc()"/> Schüler</td>
                        </tr>
                        <tr>
                            <td></td>
                            <?php
                                if (is_writeable('/home/students') && is_writeable('/home/teachers')) {
                            ?>
                            <td><input type="checkbox" id="createhome" checked/>&nbsp;Home-Verzeichnisse erstellen</td>
                            <?php
                                } else {
                            ?>
                            <td><input type="checkbox" id="createhome" onclick="return false;"/>&nbsp;<s>Home-Verzeichnisse erstellen</s><p style="color: red;">Keine Schreibrechte in /home/students und / oder /home/teachers!</p></td>
                            <?php
                                }
                            ?>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p><b>Vorschau (erste Zeile):</b></p>
        <table>
            <tr>
                <td>Nutzername:</td>
                <td id="cn-pre"></td>
            </tr>
            <tr>
                <td>Vorname:</td>
                <td id="givenname-pre"></td>
            </tr>
            <tr>
                <td>Nachname:</td>
                <td id="sn-pre"></td>
            </tr>
            <tr>
                <td>Home-Laufwerk:</td>
                <td id="home-pre"></td>
            </tr>
            <tr>
                <td>Gruppe:</td>
                <td id="group-pre"></td>
            </tr>
            <tr>
                <td>Klasse:</td>
                <td id="class-pre"></td>
            </tr>
            <tr>
                <td>Geburtsdatum:</td>
                <td id="gebdat-pre"></td>
            </tr>
            <tr>
                <td>E-Mail Addresse:</td>
                <td id="mail-pre"></td>
            </tr>
            <tr>
                <td>Passwort:</td>
                <td id="password-pre"></td>
            </tr>
        </table>
        <table>
            <tr>
                <td><button onclick="goBack()">Abbrechen</button></td>
                <td><button onclick="doImport()">CSV importieren</button></td>
            </tr>
        </table>
    </div>
    <script src="ressources/js/jquery.js"></script>
    <script src="ressources/js/swal.js"></script>
    <script src="ressources/js/accents.js"></script>
    <script>
        var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
        var inputArray = [];
        var importCounter = 0;
        function goBack() {
            window.location.href = 'index.php';
        }
        function getAjaxRequest() {
            var ajax = null;
            ajax = new XMLHttpRequest;
            return ajax;
        }
        function loadCsv() {
            inputArray = document.getElementById('csv').value.replace(/\r\n/g, '\n').split('\n');
            doCsvPrecalc();
        }
        function convertDate(input) {
            if (document.getElementById('dspacer-1').value == document.getElementById('dspacer-2').value) {
                var inputDateOne = input.split(document.getElementById('dspacer-1').value);
                if (document.getElementById('two').value == '1') {
                    var day = inputDateOne[1];
                } else if (document.getElementById('two').value == '2') {
                    var month = inputDateOne[1];
                } else if (document.getElementById('two').value == '3') {
                    var year = inputDateOne[1];
                }
                if (document.getElementById('three').value == '1') {
                    var day = inputDateOne[2];
                } else if (document.getElementById('three').value == '2') {
                    var month = inputDateOne[2];
                } else if (document.getElementById('three').value == '3') {
                    var year = inputDateOne[2];
                }
            } else {
                var inputDateOne = input.split(document.getElementById('dspacer-1').value);
                var inputDateTwo = inputDateOne[1].split(document.getElementById('dspacer-2').value);
                if (document.getElementById('two').value == '1') {
                    var day = inputDateTwo[0];
                } else if (document.getElementById('two').value == '2') {
                    var month = inputDateTwo[0];
                } else if (document.getElementById('two').value == '3') {
                    var year = inputDateTwo[0];
                }
                if (document.getElementById('three').value == '1') {
                    var day = inputDateTwo[1];
                } else if (document.getElementById('three').value == '2') {
                    var month = inputDateTwo[1];
                } else if (document.getElementById('three').value == '3') {
                    var year = inputDateTwo[1];
                }
            }
            if (document.getElementById('one').value == '1') {
                var day = inputDateOne[0];
            } else if (document.getElementById('one').value == '2') {
                var month = inputDateOne[0];
            } else if (document.getElementById('one').value == '3') {
                var year = inputDateOne[0];
            }
            if (day.length == 1) {
                var zeroedDay = '0' + day;
            } else {
                var zeroedDay = day;
            }
            if (month.length == 1) {
                var zeroedMonth = '0' + month;
            } else {
                var zeroedMonth = month;
            }
            return zeroedDay + '.' + zeroedMonth + '.' + year;
        }
        function doCsvPrecalc() {
            if (document.getElementById('password-checkbox').checked) {
                document.getElementById('password').disabled = true;
            } else {
                document.getElementById('password').disabled = false;
            }
            var cache = inputArray[0].split(document.getElementById('spacer').value);
            if (document.getElementById('teachers').checked) {
                var group = 'Lehrer';
            } else if (document.getElementById('students').checked) {
                var group = 'Schüler';
            }
            var cn = cache[(parseInt(document.getElementById('givenname').value) - 1)] + '.' + cache[(parseInt(document.getElementById('sn').value) - 1)];
            cn = removeDiacritics(cn);
            document.getElementById('cn-pre').innerHTML = cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            document.getElementById('givenname-pre').innerHTML = cache[(parseInt(document.getElementById('givenname').value) - 1)] || '';
            document.getElementById('sn-pre').innerHTML = cache[(parseInt(document.getElementById('sn').value) - 1)] || '';
            if (document.getElementById('teachers').checked) {
                document.getElementById('home-pre').innerHTML = '/home/teachers/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            } else {
                document.getElementById('home-pre').innerHTML = '/home/students/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            }
            document.getElementById('group-pre').innerHTML = group || '';
            document.getElementById('class-pre').innerHTML = cache[(parseInt(document.getElementById('class').value) - 1)] || '';
            document.getElementById('mail-pre').innerHTML = cache[(parseInt(document.getElementById('mail').value) - 1)] || '';
            document.getElementById('gebdat-pre').innerHTML = convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)]) || '';
            if (document.getElementById('password-checkbox').checked) {
                document.getElementById('password-pre').innerHTML = convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)]) || '';
            } else {
                document.getElementById('password-pre').innerHTML = cache[(parseInt(document.getElementById('password').value) - 1)] || '';
            }
        }
        function doImport() {
            swal({
                title: 'CSV importieren?',
                showCancelButton: true,
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Importieren",
                cancelButtonText: "Abbrechen",
                allowOutsideClick: false,
                allowEscapeKey: false,
                type: 'question',
                preConfirm: function (email) {
                    return new Promise(function (resolve, reject) {
                        doSend();
                    })
                },
            })
        }
        function doSend() {
            if (document.getElementById('teachers').checked) {
                var group = 'teachers';
            } else {
                var group = 'students';
            }
            if (document.getElementById('createhome').checked) {
                var createHome = '1';
            } else {
                var createHome = '0';
            }
            request = getAjaxRequest();
            var cache = inputArray[importCounter].split(document.getElementById('spacer').value);
            var cn = cache[(parseInt(document.getElementById('givenname').value) - 1)] + '.' + cache[(parseInt(document.getElementById('sn').value) - 1)];
            var url = "../api/addaccount.php";
            var givenname = cache[(parseInt(document.getElementById('givenname').value) - 1)] || '';
            var sn = cache[(parseInt(document.getElementById('sn').value) - 1)] || '';
            if (document.getElementById('teachers').checked) {
                var home = '/home/teachers/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            } else {
                var home = '/home/students/' + cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            }
            var classVar = cache[(parseInt(document.getElementById('class').value) - 1)] || '';
            var cn = cn.replace(/ /g, '_').toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae').replace(/ß/g, 'ss');
            cn = removeDiacritics(cn);
            var gebdat = convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)]) || '';
            var mail = cache[(parseInt(document.getElementById('mail').value) - 1)] || '';
            if (document.getElementById('password-checkbox').checked) {
                var password = convertDate(cache[(parseInt(document.getElementById('gebdat').value) - 1)]) || '';
            } else {
                var password = cache[(parseInt(document.getElementById('password').value) - 1)] || '';
            }
            var params = "givenname="+givenname+"&sn="+sn+"&home="+home+"&class="+classVar+"&cn="+cn+"&group="+group+"&gebdat="+gebdat+"&email="+mail+"&createhome="+createHome+"&passwd="+password;
            request.onreadystatechange=stateChangedSave;
            request.open("POST",url,true);
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            request.setRequestHeader("Content-length", params.length);
            request.setRequestHeader("Connection", "close");
            request.send(params);
            function stateChangedSave() {
                if (request.readyState == 4) {
                    if (request.responseText == "success") {
                        if (importCounter < (inputArray.length - 1)) {
                            importCounter++;
                            doSend();
                        } else {
                            finishImport();
                        }
                    } else if (request.responseText == "add_error") {
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen. " + importCounter + " Nutzer sind bereits importiert.",
                            type: "error",
                        })
                    } else if (request.responseText == "group_error") {
                        importCounter++;
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen. " + importCounter + " Nutzer sind bereits importiert, 1 Nutzer ist teilweise importiert.",
                            type: "warning",
                        })
                    } else if (request.responseText == "update_error") {
                        importCounter++;
                        swal({
                            title: "Es ist ein schwerwiegender Fehler aufgetreten.",
                            text: "WARNUNG: " + importCounter + " Nutzer wurde hinzugrfügt, jedoch konnte die User-ID nicht erhöht werden. Dies wird zu Sicherheitsproblemen führen, sollten Sie einen weiteren Nutzer hinzufügen!",
                            type: "error",
                        })
                    } else if (request.responseText == "homefolder_error") {
                        swal({
                            title: "Es kommte kein Home-Ordner angelegt werden.",
                            text: "Anscheinend kann PHP nicht in /home/teachers und /home/students schreiben. Bitte lege den Ordner manuell an.",
                            type: "error",
                        })
                    } else {
                        swal({
                            title: "Es ist ein Fehler aufgetreten.",
                            text: "Bitte erneut versuchen. " + importCounter + " Nutzer sind bereits importiert.",
                            type: "error",
                        })
                    }
                }
            }
        }
        function finishImport() {
            swal({
                title: 'CSV erfolgreich importiert',
                type: 'success',
            }).then(function() {
                window.location.href = 'index.php';
            })
        }
    </script>
</body>
</html>